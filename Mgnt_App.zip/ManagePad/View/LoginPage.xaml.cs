﻿using ManagePad.Global;
using ManagePad.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace ManagePad.View
{
    public partial class LoginPage : ContentPage
    {
        private LoginPageViewModel loginViewModel;
        public LoginPage()
        {
            InitializeComponent();
            loginViewModel = App.Locator.Login;
            BindingContext = loginViewModel;
        }

        private void BtnForgot_Clicked(object sender, EventArgs e)
        {
            //  Navigation.PushAsync(new ForgotPassword());
        }


        private void BtnSignUp_Clicked(object sender, EventArgs e)
        {
            // Navigation.PushAsync(new SignUpPage());
        }

        private void BtnGP_Clicked(object sender, EventArgs e)
        {
            Constant.IsGoogleLogin = true;
            // this.Navigation.PushAsync(new LoginWithGmail());
        }

        private void BtnFB_Clicked(object sender, EventArgs e)
        {
            Constant.IsFacebookLogin = true;
            // this.Navigation.PushAsync(new LoginWithGmail());
        }
    }
}
