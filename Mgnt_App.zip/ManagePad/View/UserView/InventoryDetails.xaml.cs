﻿using ManagePad.ViewModel;
using Plugin.Connectivity;
using Plugin.Connectivity.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace ManagePad.View.UserView
{
    public partial class InventoryDetails : ContentPage
    {

        private InventoryViewModel inventoryViewModel;
        public InventoryDetails()
        {
            InitializeComponent();
            Title = "Inventory Sheet";
            inventoryViewModel = App.Locator.Inventory;
            BindingContext = inventoryViewModel;
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();
            CrossConnectivity.Current.ConnectivityChanged += Current_ConnectivityChanged;
            await inventoryViewModel.Init();
            
        }

        public void itemTapped(object sender, ItemTappedEventArgs e)
        {

            this.Navigation.PushAsync(new InventoryEdit(e.Item));
        }

        private void Current_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            if (!e.IsConnected)
            {
                stkNoConnection.IsVisible = true;
                stk.IsVisible = false;
            }
            else
            {
                stkNoConnection.IsVisible = false;
                stk.IsVisible = true;
            }
        }

    }
}
