﻿using ManagePad.Model.UserModel;
using ManagePad.ViewModel;
using Plugin.Connectivity;
using Plugin.Connectivity.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace ManagePad.View.UserView
{
    public partial class InventoryEdit : ContentPage
    {

        InventoryModel inventoryModel;
        InventoryItemEditViewModel inventoryItemEditViewModel;
        public InventoryEdit(object obj)
        {
           InitializeComponent();
            this.inventoryModel = (InventoryModel)obj;
            this.inventoryItemEditViewModel = App.Locator.InventoryItemEdit;
            BindingContext = inventoryItemEditViewModel;

        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();
            CrossConnectivity.Current.ConnectivityChanged += Current_ConnectivityChanged;

            await this.inventoryItemEditViewModel.Init(inventoryModel.ID);
          
        }

        public void itemTapped(object sender, ItemTappedEventArgs e)
        {

            //  this.Navigation.PushAsync(new InventoryEdit(e.Item));
        }

        private void Current_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            if (!e.IsConnected)
            {
                stkNoConnection.IsVisible = true;
                stk.IsVisible = false;
            }
            else
            {
                stkNoConnection.IsVisible = false;
                stk.IsVisible = true;
            }
        }


        private void OnSaveClick(object sender, EventArgs e)
        {
            this.inventoryItemEditViewModel.SaveAllInventoryItems();
        }
    }

    public class CustomCell : ViewCell
    {
        public CustomCell()
        {
            #region Code that Customizes Cell

            AbsoluteLayout cellView = new AbsoluteLayout();
            var retailernameLabel = new Label();
            AbsoluteLayout.SetLayoutBounds(retailernameLabel, new Rectangle(5, 12, AbsoluteLayout.AutoSize, AbsoluteLayout.AutoSize));
            retailernameLabel.SetBinding(Label.TextProperty, new Binding("InventoryItemName"));
            retailernameLabel.FontSize = 18;
            retailernameLabel.TextColor = Color.FromHex("#434343");
            cellView.Children.Add(retailernameLabel);

            var txtAmt = new Entry();
            AbsoluteLayout.SetLayoutBounds(txtAmt, new Rectangle(5, 32, 500, 60));
            txtAmt.SetBinding(Entry.TextProperty, new Binding("Quantity", BindingMode.TwoWay));
            txtAmt.Keyboard = Keyboard.Numeric;
            txtAmt.TextColor = Color.Black;
            cellView.Children.Add(txtAmt);

            this.View = cellView;

            View = new StackLayout()
            {
                Children = { cellView }
            };
            #endregion
        }
    }
}
