﻿using ManagePad.Global;
using ManagePad.ViewModel.UserViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace ManagePad.View.UserView
{
    public partial class MenuPage : ContentPage
    {
       

        public ListView MenuOptionListView //expose list to public i.e. MenuController
        {
            get { return menuOptionListView; }
        }

        private UserMenuItemViewModel userMenu;



        public MenuPage()
        {
            InitializeComponent();
            userMenu = App.Locator.UserMenu;
            BindingContext = userMenu;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();


            lblName.Text = App.baseUser.Username;
            lblEmail.Text = "";
            

            //if (App.setting_Model.userModel != null)
            //{
            //    lblName.Text = App.setting_Model.userModel.FirstName + App.setting_Model.userModel.LastName;
            //    lblEmail.Text = App.setting_Model.userModel.EmailId;
            //    imageName.Source= App.setting_Model.userModel.UserImg;
            //  //  var base64EncodedBytes = Convert.FromBase64String(image);
            //   //imageName.Source= ImageSource.FromStream(() => new MemoryStream(base64EncodedBytes));
            //}
        }
    }
}
