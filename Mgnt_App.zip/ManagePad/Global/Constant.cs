﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagePad.Global
{
    public class Constant

    {

        public static string BaseUrl = "https://managepad.com/mobileapi/";
       // public static string BaseUrl = "http://localhost:49407/mobileapi/";
        public static string BaseUserImageUrl = "https://managepad.com/images/user/";
        public static string BaseProductImageUrl = "https://managepad.com/images/product/";

        public static bool IsGoogleLogin = false;
        public static bool IsFacebookLogin = false;

        public static bool IsAddressFilled = false;

    }
}
