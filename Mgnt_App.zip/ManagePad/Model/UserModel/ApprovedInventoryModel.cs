﻿using ManagePad.Global;

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagePad.Model.UserModel
{
    public class ApprovedInventoryModel
    {

        public int ID { get; set; }
        public Guid UniqueKey { get; set; }
        public int InventoryItemId { get; set; }

        public int InventoryId { get; set; }



        public decimal? Quantity { get; set; }
        public decimal? Price { get; set; }

        public decimal? ParValue { get; set; }
        public decimal? MinOrder { get; set; }
        public decimal? Order { get; set; }



        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }


        public int VendorId { get; set; }
        public string Vendor { get; set; }
        public int CategoryId { get; set; }
        public string Category { get; set; }



        public string InventoryItemName { get; set; }
        public string InventoryItemDescription { get; set; }

        public string InventoryItemUnit { get; set; }
    }
}
