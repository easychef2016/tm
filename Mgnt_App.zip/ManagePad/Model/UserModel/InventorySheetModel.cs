﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagePad.Model.UserModel
{
    public class InventorySheetModel
    {

        public InventorySheetModel()
        {
            ApprovedInventories = new ObservableCollection<ApprovedInventoryModel>();

        }

        public int ID { get; set; }

        public string Name { get; set; }
        public Nullable<DateTime> InventoryDate { get; set; }
        public bool Status { get; set; }
        public string loginUserInfo { get; set; }
        public string Restaurant { get; set; }
        public int RestaurantId { get; set; }

        public string Vendor { get; set; }
        public int VendorId { get; set; }

        public int SenttoVendor { get; set; }
        public Nullable<DateTime> SenttoVendorDate { get; set; }



        public ObservableCollection<ApprovedInventoryModel> ApprovedInventories { get; set; }
    }

    public class RootObjectInventorySheet
    {
        public int StatusCode { get; set; }
        public string ResponseMessage { get; set; }
        public ObservableCollection<InventorySheetModel> Result { get; set; }
    }
}
