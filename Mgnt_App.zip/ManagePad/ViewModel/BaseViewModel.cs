﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Views;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

using Xamarin.Forms;
using ManagePad.Model.UserModel;

namespace ManagePad.ViewModel
{
    public class BaseViewModel : ViewModelBase
    {

        public bool IsValidPassword(string strnIn)
        {
            try
            {
                return Regex.IsMatch(strnIn, "(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,15})$",
                RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));

            }
            catch (RegexMatchTimeoutException)
            {
                return false;

            }
        }


        public bool IsValidEmail(string strnIn)
        {
            try
            {
                return Regex.IsMatch(strnIn, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$",
                RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));

            }
            catch (RegexMatchTimeoutException)
            {
                return false;

            }
        }


        public bool IsValidMobile(string strIn)
        {
            int length = strIn.Length;
            if (length > 10)
                return false;
            return true;
        }


        #region AddCommand
        private Command addCommand;
        public Command AddCommand
        {
            get
            {
                return new Command<InventoryModel>(item =>
                {
                    //if (item.Qty <= 0)
                    //{
                    //    //UserDialogs.Instance.Alert("Item Not Available", null, "OK");
                    //}
                    //else
                    //{

                    //    item.Qty = item.Qty - 1;
                    //  //  cartList.Add(item);
                    // //   AddCartCount();
                    // //   UserDialogs.Instance.Alert("Added to Cart", "Success", "OK");

                    //}
                });
            }

        }

        #endregion
    }
}
