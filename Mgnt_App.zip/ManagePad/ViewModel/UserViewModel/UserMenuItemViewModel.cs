﻿using ManagePad.Global;
using ManagePad.Model.UserModel;
using ManagePad.View;
using ManagePad.View.UserView;
using GalaSoft.MvvmLight;

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagePad.ViewModel.UserViewModel
{
    public class UserMenuItemViewModel : BaseViewModel
    {
        private string _base64_Img;
        public string _Base64_Img
        {
            get { return _base64_Img; }
            set { _base64_Img = value; RaisePropertyChanged("_Base64_Img"); }
        }

        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; RaisePropertyChanged(() => FirstName); }
        }

        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; RaisePropertyChanged(() => LastName); }
        }

        private string email;
        public string Email
        {
            get { return email; }
            set { email = value; RaisePropertyChanged(() => Email); }
        }


        ObservableCollection<UserMenuItemModel> menuItems;
        public ObservableCollection<UserMenuItemModel> MenuItems
        {
            get { return menuItems; }
            set
            {
                menuItems = value;
                RaisePropertyChanged("menuItems");
            }
        }
        public UserMenuItemViewModel()
        {
            UserModel user = App.baseUser;
          //  Email = user.EmailId;
           FirstName = user.Username;
          //  LastName = user.LastName;
          //  _Base64_Img = Constant.BaseUserImageUrl + user.UserImage;

            MenuItems = new ObservableCollection<UserMenuItemModel>
                {
                     new UserMenuItemModel
                    {
                        MenuItemTitle="Restaurant",MenuItemIconSource="ic_action_restaurant.png",PageType=typeof(RestaurantProfile)
                    },
                     new UserMenuItemModel
                    {
                        MenuItemTitle="Inventory",MenuItemIconSource="ic_action_bargraph.png",PageType=typeof(InventoryDetails)
                    },
                      new UserMenuItemModel
                    {
                        MenuItemTitle="Inventory Item",MenuItemIconSource="ic_action_bargraph.png",PageType=typeof(InventoryItemdetails)
                    },
                      
                        new UserMenuItemModel
                    {
                        MenuItemTitle="Logout",MenuItemIconSource="ic_action_io.png",PageType=typeof(LoginPage)
                    },

        };
        }



    }
}
