﻿using Acr.UserDialogs;
using ManagePad.Model.Response;
using ManagePad.Model.UserModel;
//using ManagePad.View.UserView;
using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using ManagePad.Helpers;
using Plugin.LocalNotifications;
using ManagePad.Services;
using ManagePad.View.UserView;

namespace ManagePad.ViewModel
{
    public class LoginPageViewModel : BaseViewModel
    {

        #region propertydeclaration
        private string email;
        public string Email
        {
            get { return email; }
            set { email = value; RaisePropertyChanged(() => Email); }
        }

        private string username;
        public string Username
        {
            get { return username; }
            set { username = value; RaisePropertyChanged(() => username); }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set { password = value; RaisePropertyChanged(() => Password); }
        }
        #endregion



        #region LoginCommand
        private Command loginCommand;
        public Command LoginCommand
        {
            get
            {
                return loginCommand ?? (loginCommand = new Command(() => ExecuteLoginCommand()));
            }
        }


        private bool CheckValidations()
        {


            if (string.IsNullOrWhiteSpace(Password))
            {
                UserDialogs.Instance.Alert("Please enter password", null, "Ok");
                return false;
            }

            else if (string.IsNullOrWhiteSpace(Email))
            {
                UserDialogs.Instance.Alert("Please enter email", null, "Ok");
                return false;
            }


            else if (!IsValidEmail(Email))
            {
                UserDialogs.Instance.Alert("Incorrect Email id", null, "Ok");
                return false;
            }
            //else if (!IsValidPassword(Password))
            //{
            //    UserDialogs.Instance.Alert("Password must contain a no.,capital letter,and size should be betwwen 8-15", null, "Cancel");
            //    return false;
            //}
            else
            {
                return true;
            }
        }
        public async void ExecuteLoginCommand()
        {

            if (CheckValidations())
            {
                UserModel user = new UserModel();
                user.Username = Email;
                user.Password = Password;

              //  if (Device.OS == TargetPlatform.Android || Device.OS == TargetPlatform.iOS)
              //  {
                    UserDialogs.Instance.ShowLoading();
              //  }
                //Rest_Response rest_result = await WebService.PostData(user, "account/authenticate");


                Rest_Response rest_result = await WebService.PostData(user, "account/authenticatemobile");
                if (rest_result != null)
                {
                    if (rest_result.status_code == 200)
                    {
                        //RootObjectLoginUserModel data = JsonConvert.DeserializeObject<RootObjectLoginUserModel>(rest_result.response_body);
                        UserModel data = JsonConvert.DeserializeObject<UserModel>(rest_result.response_body);


                        if (data.EmailId != null)
                        {
                            var userobj = data;
                            App.baseUser = userobj;
                            App.setting_Model.userModel = userobj;
                            var sUser = JsonConvert.SerializeObject(App.setting_Model);
                            Settings.GeneralSettings = sUser;
                            App.Current.MainPage = new UserMasterController();


                        }
                        else
                        {
                         //   if (Device.OS == TargetPlatform.Android || Device.OS == TargetPlatform.iOS)
                        //    {
                              //  UserDialogs.Instance.HideLoading();
                                UserDialogs.Instance.Alert("Invalid Username or Password", null, "OK");
                        //    }
                        }




                        //if (data.StatusCode == 200)
                        //{
                        //    var userobj = data.user_detail;
                        //    if (userobj.IsAdmin)
                        //    {
                        //       // App.Current.MainPage = new AdminMasterController();
                        //    }
                        //    else
                        //    {

                        //        App.baseUser = userobj;
                        //        App.setting_Model.userModel = userobj;
                        //        var sUser = JsonConvert.SerializeObject(App.setting_Model);
                        //        Settings.GeneralSettings = sUser;
                        //        App.Current.MainPage = new UserMasterController();


                        //    }
                        //}
                        //else
                        //{
                        //    if (Device.OS == TargetPlatform.Android || Device.OS == TargetPlatform.iOS)
                        //    {
                        //        UserDialogs.Instance.Alert("Invalid Username or Password", null, "OK");
                        //    }
                        //}

                    }

                }
              //  if (Device.OS == TargetPlatform.Android || Device.OS == TargetPlatform.iOS)
             //   {
                    UserDialogs.Instance.HideLoading();
            //    }

            }


        }

        #endregion
    }
}
