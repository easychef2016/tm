﻿using ManagePad.Model.Response;
using ManagePad.Model.UserModel;
using ManagePad.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight.Command;
//using Xamarin.Forms;
using System.Windows.Input;
using System.ComponentModel;

namespace ManagePad.ViewModel
{
    public class InventoryItemEditViewModel: INotifyPropertyChanged
    {
        private List<ApprovedInventoryModel> approvedInventoriesList;
        public List<ApprovedInventoryModel> ApprovedInventoriesList {
            get { return approvedInventoriesList; }
            set
            {
                approvedInventoriesList = value;
                OnPropertyChanged("ApprovedInventoriesList");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged?.Invoke(this,
                new PropertyChangedEventArgs(propertyName));
        }

        private ObservableCollection<ApprovedInventoryViewModel> approvedInventories;
        public ObservableCollection<ApprovedInventoryViewModel> ApprovedInventories
        {
            get { return approvedInventories; }
            set
            {
                approvedInventories = value;
               // RaisePropertyChanged("ApprovedInventories");
               // RaisePropertyChanged("Quantity");
            }
        }

        public InventoryItemEditViewModel()
        {
            // ApprovedInventories = new ObservableCollection<ApprovedInventoryViewModel>();
            //ApprovedInventoriesList = new List<ApprovedInventoryModel>();
        }


        public async Task Init(int inventoryId)
        {


            Rest_Response rest_result = await WebService.GetData("inventories/detailsedit/" + inventoryId);
            if (rest_result != null)
            {
                if (rest_result.status_code == 200)
                {
                    InventorySheetModel data = JsonConvert.DeserializeObject<InventorySheetModel>(rest_result.response_body);

                    this.ApprovedInventories = new ObservableCollection<ApprovedInventoryViewModel>();

                    this.ApprovedInventoriesList= new List<ApprovedInventoryModel>();

                    //foreach (var ApprovedInventory in data.ApprovedInventories)
                    //{
                    //    ApprovedInventories.Add(new ApprovedInventoryViewModel
                    //    {
                    //        ID = ApprovedInventory.ID,
                    //        InventoryId = ApprovedInventory.InventoryId,
                    //        InventoryItemName = ApprovedInventory.InventoryItemName,
                    //        Quantity = ApprovedInventory.Quantity,
                    //        ParValue = ApprovedInventory.ParValue,
                    //        Order = ApprovedInventory.Order
                    //    }

                    //    );
                    //}


                    foreach (var ApprovedInventory in data.ApprovedInventories)
                    {
                        ApprovedInventoriesList.Add(new ApprovedInventoryModel
                        {
                            ID = ApprovedInventory.ID,
                            InventoryId = ApprovedInventory.InventoryId,
                            InventoryItemName = ApprovedInventory.InventoryItemName,
                            Quantity = ApprovedInventory.Quantity,
                            ParValue = ApprovedInventory.ParValue,
                            Order = ApprovedInventory.Order
                        }

                        );
                    }

                   





                }

            }

        }

        public ICommand SaveInventoryCommand { get { return new RelayCommand(SaveInventoryItems); } }

        public void SaveInventoryItems()
        {

            foreach (var approvedInventories in ApprovedInventoriesList)
            {
                if (approvedInventories.ID != 0)
                {
                    // database.Update(customerInstance);
                }
                else
                {
                    // database.Insert(customerInstance);
                }
            }

        }

        //private Command saveInventoryItems;
        //public Command SaveInventoryItems
        //{
        //    get
        //    {
        //        return saveInventoryItems ?? (saveInventoryItems = new Command(() => SaveAllInventoryItems()));
        //    }
        //}
        public void SaveAllInventoryItems()
        {
            
                foreach (var approvedInventories in this.ApprovedInventories)
                {
                    if (approvedInventories.ID != 0)
                    {
                       // database.Update(customerInstance);
                    }
                    else
                    {
                       // database.Insert(customerInstance);
                    }
                }
            
        }



    }
}
