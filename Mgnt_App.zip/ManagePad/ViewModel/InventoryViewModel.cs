﻿using Acr.UserDialogs;
using ManagePad.Model.Response;
using ManagePad.Model.UserModel;
using ManagePad.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ManagePad.ViewModel
{
    public class InventoryViewModel : BaseViewModel
    {




        private ObservableCollection<InventoryModel> inventoryList;
        public ObservableCollection<InventoryModel> InventoryList
        {
            get { return inventoryList; }
            set
            {
                inventoryList = value;
                RaisePropertyChanged("InventoryList");
            }
        }


        public InventoryViewModel()
        {
            Task.Run(() => Init());
        }

        public async Task Init()
        {

            UserModel user = App.baseUser;
            InventoryList = await GetInventories(user.EmailId);

            var query = from p in InventoryList

                        select p;
            InventoryList = new ObservableCollection<InventoryModel>(query);


        }

        public async Task<ObservableCollection<InventoryModel>> GetInventories(string userEmailID)
        {
            ObservableCollection<InventoryModel> inventoriesListresult = null;

           
             // UserDialogs.Instance.ShowLoading();
          


            Rest_Response rest_result = await WebService.GetData("inventories/latest/?filter=" + userEmailID);
            if (rest_result != null)
            {
                if (rest_result.status_code == 200)
                {
                    InventoryModel[] data = JsonConvert.DeserializeObject<InventoryModel[]>(rest_result.response_body);
                    //if (data.StatusCode == 200)
                    //{
                    //    inventoriesList = data.Result;
                    //}

                    InventoryModel inventorymodel = null;
                    inventoriesListresult = new ObservableCollection<InventoryModel>();

                    foreach (var inventory in data)
                    {
                        inventorymodel = new InventoryModel
                        {
                            ID = inventory.ID,
                            Name = inventory.Name,
                            SenttoVendor = inventory.SenttoVendor,
                            InventoryDate = inventory.InventoryDate

                        };
                        inventoriesListresult.Add(inventorymodel);

                    }


                }

            }
            
               // UserDialogs.Instance.HideLoading();
           
            return inventoriesListresult;
        }


    }
}
