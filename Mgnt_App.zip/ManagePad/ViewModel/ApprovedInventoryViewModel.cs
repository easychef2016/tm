﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Views;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagePad.ViewModel
{
    public class ApprovedInventoryViewModel: ViewModelBase
    {

        private int id;
        private Guid uniqueKey;
        private int inventoryItemId;

        private int inventoryId;



        private decimal? quantity;
        private decimal? price;

        private decimal? parValue;
        private decimal? minOrder;
        private decimal? order;



        private bool status;

        private Nullable<DateTime> createdDate;
        private String createdBy;
        private Nullable<DateTime> updatedDate;
        private String updatedBy;

        private int vendorId;
        private string vendor;
        private int categoryId;
        private string category;



        private string inventoryItemName;
        private string inventoryItemDescription;

        private string inventoryItemUnit;


        public int ID
        {
            get { return id; }
            set
            {
                this.id = value;

                RaisePropertyChanged(() => ID);
            }
        }


        public Guid UniqueKey
        {
            get { return uniqueKey; }
            set { this.uniqueKey = value; RaisePropertyChanged(() => UniqueKey); }
        }
        public int InventoryItemId
        {
            get { return inventoryItemId; }
            set { this.inventoryItemId = value; RaisePropertyChanged(() => InventoryItemId); }
        }

        public int InventoryId
        {
            get { return inventoryId; }
            set { this.inventoryId = value; RaisePropertyChanged(() => InventoryId); }
        }



        public decimal? Quantity
        {
            get { return quantity; }
            set
            {

                if (this.quantity != value)
                {
                    this.quantity = value;
                    RaisePropertyChanged(() => Quantity);
                    
                }


                
            }
        }
        public decimal? Price
        {
            get { return price; }
            set { this.price = value; RaisePropertyChanged(() => Price); }
        }

        public decimal? ParValue
        {
            get { return parValue; }
            set { this.parValue = value; RaisePropertyChanged(() => ParValue); }
        }
        public decimal? MinOrder
        {
            get { return minOrder; }
            set { this.minOrder = value; RaisePropertyChanged(() => MinOrder); }
        }
        public decimal? Order
        {
            get { return order; }
            set { this.order = value; RaisePropertyChanged(() => Order); }
        }



        public bool Status
        {
            get { return status; }
            set { this.status = value; RaisePropertyChanged(() => Status); }
        }

        public Nullable<DateTime> CreatedDate
        {
            get { return createdDate; }
            set { this.createdDate = value; RaisePropertyChanged(() => CreatedDate); }
        }
        public String CreatedBy
        {
            get { return createdBy; }
            set { this.createdBy = value; RaisePropertyChanged(() => CreatedBy); }
        }
        public Nullable<DateTime> UpdatedDate
        {
            get { return updatedDate; }
            set { this.updatedDate = value; RaisePropertyChanged(() => UpdatedDate); }
        }
        public String UpdatedBy
        {
            get { return updatedBy; }
            set { this.updatedBy = value; RaisePropertyChanged(() => UpdatedBy); }
        }


        public int VendorId
        {
            get { return vendorId; }
            set { this.vendorId = value; RaisePropertyChanged(() => VendorId); }
        }
        public string Vendor
        {
            get { return vendor; }
            set { this.vendor = value; RaisePropertyChanged(() => Vendor); }
        }
        public int CategoryId
        {
            get { return categoryId; }
            set { this.categoryId = value; RaisePropertyChanged(() => CategoryId); }
        }
        public string Category
        {
            get { return category; }
            set { this.category = value; RaisePropertyChanged(() => Category); }
        }



        public string InventoryItemName
        {
            get { return inventoryItemName; }
            set { this.inventoryItemName = value; RaisePropertyChanged(() => InventoryItemName); }
        }
        public string InventoryItemDescription
        {
            get { return inventoryItemDescription; }
            set { this.inventoryItemDescription = value; RaisePropertyChanged(() => InventoryItemDescription); }
        }

        public string InventoryItemUnit
        {
            get { return inventoryItemUnit; }
            set { this.inventoryItemUnit = value; RaisePropertyChanged(() => InventoryItemUnit); }
        }


    }
}
