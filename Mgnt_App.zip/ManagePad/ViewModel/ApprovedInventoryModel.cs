﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagePad.ViewModel
{
    public class ApprovedInventoryModel: INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged?.Invoke(this,
                new PropertyChangedEventArgs(propertyName));
        }


        private int id;
        private Guid uniqueKey;
        private int inventoryItemId;

        private int inventoryId;



        private decimal? quantity;
        private decimal? price;

        private decimal? parValue;
        private decimal? minOrder;
        private decimal? order;



        private bool status;

        private Nullable<DateTime> createdDate;
        private String createdBy;
        private Nullable<DateTime> updatedDate;
        private String updatedBy;

        private int vendorId;
        private string vendor;
        private int categoryId;
        private string category;



        private string inventoryItemName;
        private string inventoryItemDescription;

        private string inventoryItemUnit;


        public int ID
        {
            get { return id; }
            set
            {
                this.id = value;

                OnPropertyChanged(nameof(ID));
            }
        }


        public Guid UniqueKey
        {
            get { return uniqueKey; }
            set { this.uniqueKey = value;
                OnPropertyChanged(nameof(UniqueKey));

            }
        }
        public int InventoryItemId
        {
            get { return inventoryItemId; }
            set { this.inventoryItemId = value; OnPropertyChanged(nameof(InventoryItemId)); }
        }

        public int InventoryId
        {
            get { return inventoryId; }
            set { this.inventoryId = value; OnPropertyChanged(nameof(InventoryId)); }
        }



        public decimal? Quantity
        {
            get { return quantity; }
            set
            {

                if (this.quantity != value)
                {
                    this.quantity = value;
                    OnPropertyChanged(nameof(Quantity));

                }



            }
        }
        public decimal? Price
        {
            get { return price; }
            set { this.price = value; OnPropertyChanged(nameof(Price)); }
        }

        public decimal? ParValue
        {
            get { return parValue; }
            set { this.parValue = value; OnPropertyChanged(nameof(ParValue)); }
        }
        public decimal? MinOrder
        {
            get { return minOrder; }
            set { this.minOrder = value; OnPropertyChanged(nameof(MinOrder)); }
        }
        public decimal? Order
        {
            get { return order; }
            set { this.order = value; OnPropertyChanged(nameof(Order)); }
        }



        public bool Status
        {
            get { return status; }
            set { this.status = value; OnPropertyChanged(nameof(Status)); }
        }

        public Nullable<DateTime> CreatedDate
        {
            get { return createdDate; }
            set { this.createdDate = value; OnPropertyChanged(nameof(CreatedDate)); }
        }
        public String CreatedBy
        {
            get { return createdBy; }
            set { this.createdBy = value; OnPropertyChanged(nameof(CreatedBy)); }
        }
        public Nullable<DateTime> UpdatedDate
        {
            get { return updatedDate; }
            set { this.updatedDate = value; OnPropertyChanged(nameof(UpdatedDate)); }
        }
        public String UpdatedBy
        {
            get { return updatedBy; }
            set { this.updatedBy = value; OnPropertyChanged(nameof(UpdatedBy)); }
        }


        public int VendorId
        {
            get { return vendorId; }
            set { this.vendorId = value; OnPropertyChanged(nameof(VendorId)); }
        }
        public string Vendor
        {
            get { return vendor; }
            set { this.vendor = value; OnPropertyChanged(nameof(Vendor)); }
        }
        public int CategoryId
        {
            get { return categoryId; }
            set { this.categoryId = value; OnPropertyChanged(nameof(CategoryId)); }
        }
        public string Category
        {
            get { return category; }
            set { this.category = value; OnPropertyChanged(nameof(Category)); }
        }



        public string InventoryItemName
        {
            get { return inventoryItemName; }
            set { this.inventoryItemName = value; OnPropertyChanged(nameof(InventoryItemName)); }
        }
        public string InventoryItemDescription
        {
            get { return inventoryItemDescription; }
            set { this.inventoryItemDescription = value; OnPropertyChanged(nameof(InventoryItemDescription)); }
        }

        public string InventoryItemUnit
        {
            get { return inventoryItemUnit; }
            set { this.inventoryItemUnit = value; OnPropertyChanged(nameof(InventoryItemUnit)); }
        }





    }
}
