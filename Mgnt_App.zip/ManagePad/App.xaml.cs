﻿


using ManagePad.ViewModel;
//-------------------------------//
using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Views;
using Newtonsoft.Json;
//-------------------------------//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;




using Xamarin.Forms;
using ManagePad.Model.UserModel;
using ManagePad.Util;
using ManagePad.Model;
using ManagePad.Helpers;
using ManagePad.View;
using ManagePad.View.UserView;

namespace ManagePad
{
    public partial class App : Application
    {

        public static UserModel baseUser = new UserModel();
        public static UserAddress address = new UserAddress();
        static App _Instance;
        static object _SyncRoot = new Object();
        public OAuthSettings OAuthSettings { get; private set; }


        public static App Instance
        {
            get
            {
                if (_Instance == null)
                {
                    lock (_SyncRoot)
                    {
                        _Instance = new App();
                        _Instance.OAuthSettings =
                            new OAuthSettings(
                                clientId: "abc.apps.googleusercontent.com",
                                scope: "https://www.googleapis.com/auth/userinfo.email",    // The scopes for the particular API you're accessing. The format for this will vary by API.
                                authorizeUrl: "https://accounts.google.com/o/oauth2/auth",   // the auth URL for the service
                                redirectUrl: "https://www.googleapis.com/plus/v1/people/me");   // the redirect URL for the service        

                    }
                }
                return _Instance;
            }
        }

        string _Token;
        public string Token
        {
            get
            {
                return _Token;
            }
        }

        public bool IsAuthenticated
        {
            get { return !string.IsNullOrWhiteSpace(_Token); }
        }

        public void SaveToken(string token)
        {
            _Token = token;
            //broadcast a message that authentication is successful
            MessagingCenter.Send<App>(this, "Authenticated");

        }
        public Action SuccessfulLoginAction
        {
            get
            {
                return new Action(() => App.Current.MainPage = new UserMasterController());
            }
        }


        private readonly static ViewModelLocator _locator = new ViewModelLocator();
        public static ViewModelLocator Locator
        {
            get { return _locator; }
        }

        public const string FirstPage = "Restaurant";
        public const string SecondPage = "Inventory";

        public static SettingModel setting_Model = new SettingModel();

        public App()
        {
            InitializeComponent();

            // MainPage = new ManagePad.MainPage();

            setting_Model = JsonConvert.DeserializeObject<SettingModel>(Settings.GeneralSettings);
            if (setting_Model != null)
            {
                if (setting_Model.IsNotFirstTime)
                {
                    MainPage = new NavigationPage(new LoginPage())
                    { BarBackgroundColor = Color.FromHex("2DCA71"), BarTextColor = Color.White };
                }
                else
                {

                    MainPage = new NavigationPage(new LoginPage())
                    { BarBackgroundColor = Color.FromHex("2DCA71"), BarTextColor = Color.White };
                    // MainPage = new NavigationPage(new CarousalPageView());
                }

            }
            else
            {
                setting_Model = new SettingModel();//as first time deserialisation will make setting model as null that why we have to initialize it
                setting_Model.IsNotFirstTime = true;
                var obj = JsonConvert.SerializeObject(setting_Model);
                Settings.GeneralSettings = obj; //again set the seeting model in settingkey hence next time set will not be null
                                                // MainPage = new CarousalPageView();
            }
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
