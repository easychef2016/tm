﻿(function (app) {
    'use strict';

    app.controller('dashboardCtrl', dashboardCtrl);

    dashboardCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService', '$rootScope'];

    function dashboardCtrl($scope, $location, $timeout, apiService, notificationService, $rootScope) {


        $scope.filterUsername = '';
        $scope.restaurantdetails = {};
        $scope.loadrestaurantdetails = loadrestaurantdetails;
        $scope.loadUserdata = loadUserdata;

        $scope.dashboarddetails = {};

        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;
                
            }
        }
        

        function loadrestaurantdetails() {
            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };
            apiService.get('/api/restaurant/details/', config,
            loadrestaurantdetailsCompleted,
            loadrestaurantdetailsFailed);
        }
        

        function loadrestaurantdetailsCompleted(response) {
            //  alert(response.data);
            $scope.restaurantdetails = response.data;
        }

        function loadrestaurantdetailsFailed(response) {
            console.log(response);
            //notificationService.displayError(response.statusText);
        }



        function loadDashboardData() {
           
            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };

            apiService.get('/api/inventories/dashboard/', config,
                       inventoryItemsLoadCompleted,
                        inventoryItemsLoadFailed);

        }

        function inventoryItemsLoadCompleted(result) {
           

              $scope.dashboarddetails = result.data;          
         //   $scope.loadinginventories = false;
        }

     
        function inventoryItemsLoadFailed(response) {
          
            notificationService.displayError(response.data);
        }


        loadUserdata();
        loadrestaurantdetails();
        loadDashboardData();


    }

})(angular.module('easychefdemo'));