﻿/// <reference path="../layout/sideBarold.html" />
(function (app) {
    'use strict';

    app.controller('rootCtrl', rootCtrl)

    .directive('treeview', function () {
        /*
         * SIDEBAR MENU
         * ------------
         * This is a custom plugin for the sidebar menu. It provides a tree view.
         *
         * Usage:
         * $(".sidebar).tree();
         *
         * Note: This plugin does not accept any options. Instead, it only requires a class
         *       added to the element that contains a sub-menu.
         *
         * When used with the sidebar, for example, it would look something like this:
         * <ul class='sidebar-menu'>
         *      <li class="treeview active">
         *          <a href="#>Menu</a>
         *          <ul class='treeview-menu'>
         *              <li class='active'><a href=#>Level 1</a></li>
         *          </ul>
         *      </li>
         * </ul>
         *
         * Add .active class to <li> elements if you want the menu to be open automatically
         * on page load. See above for an example.
         */
        $.fn.tree = function () {
            return this.each(function () {
                var btn = $(this).children("a").first();
                var menu = $(this).children(".treeview-menu").first();
                var isActive = $(this).hasClass('active');

                //initialize already active menus
                if (isActive) {
                    menu.show();
                    btn.children(".fa-angle-left").first().removeClass("fa-angle-left").addClass("fa-angle-down");
                }
                //Slide open or close the menu on link click
                btn.click(function (e) {
                    e.preventDefault();
                    if (isActive) {
                        //Slide up to close menu
                        menu.slideUp();
                        isActive = false;
                        btn.children(".fa-angle-down").first().removeClass("fa-angle-down").addClass("fa-angle-left");
                        btn.parent("li").removeClass("active");
                    } else {
                        //Slide down to open menu
                        menu.slideDown();
                        isActive = true;
                        btn.children(".fa-angle-left").first().removeClass("fa-angle-left").addClass("fa-angle-down");
                        btn.parent("li").addClass("active");
                    }
                });

                /* Add margins to submenu elements to give it a tree look */
                menu.find("li > a").each(function () {
                    var pad = parseInt($(this).css("margin-left")) + 10;

                    $(this).css({
                        "margin-left": pad + "px"
                    });
                });

            });

        };
        return {
            restrict: 'C',
            link: function (scope, element, attrs) {
                element.tree();
            }
        };
    });
    

    //rootCtrl.$inject = ['$scope', '$location', 'membershipService', '$rootScope', '$mdSidenav', '$state'];
    //function rootCtrl($scope, $location, membershipService, $rootScope, $mdSidenav, $state) {
    rootCtrl.$inject = ['$scope', '$location', 'membershipService', '$rootScope', '$cookies', '$state'];
    function rootCtrl($scope, $location, membershipService, $rootScope,$cookies,$state) {
      
        $scope.userData = {};
        $scope.userData.displayUserInfo = displayUserInfo;
        $scope.logout = logout;
        $scope.gotoProfile = gotoProfile;
        // $rootScope.repository = {
        //      loggedUser: {
        //          username:'',
        //          authdata: ''
        //       }
        //   };

        // $rootScope.repository = $cookies.getObject('repository') || {};
        // debugger;
        //if ($rootScope.repository.loggedUser) {
        //    $http.defaults.headers.common['Authorization'] = $rootScope.repository.loggedUser.authdata;

        //}



        function displayUserInfo() {
            $scope.userData.isUserLoggedIn = membershipService.isUserLoggedIn();

            if ($scope.userData.isUserLoggedIn) {
                $scope.username = $rootScope.repository.loggedUser.username;
            }
        }

        function logout() {
           
            membershipService.removeCredentials();
            // $location.path('#/');
            $location.path('/');
            $scope.userData.displayUserInfo();
        }
        function gotoProfile() {         
           // $state.go("Management.Profile");
            $state.go("Management.UserManagement");

            
        }

        

        function login() {           
            $state.go("login");
        }

        $scope.userData.displayUserInfo();




        //Added as part of Angular Material

      //  $scope.menuItems = [
      //{ name: 'home', path: 'home' },
      //{ name: 'login', path: 'login' },
      //{ name: 'register', path: 'register' },
      //{ name: 'Management', path: 'Management' },
      //{ name: 'Management.recipies', path: 'Management.recipies' },
      //{ name: 'grid list', path: 'gridList' },
      //{ name: 'input', path: 'input' },
      //{ name: 'progress circular', path: 'progressCircular' },
      //{ name: 'progress linear', path: 'progressLinear' },
      //{ name: 'toast', path: 'toast' },
      //{ name: 'whiteframe', path: 'whiteframe' },
      //  ];

      //  $scope.title = 'home';

      //  $scope.go = function (path, title) {
      //      $state.go(path);
      //      $scope.title = title;
      //  }

        //$scope.toggleLeft = function () {
        //    $mdSidenav('left')
        //          .toggle();
        //}

        //$scope.menuIcon = 'menu';
        //$scope.menuToggle = function () {
        //    if ($scope.menuIcon == 'menu') {
        //        $mdSidenav('left')
        //          .open();
        //        $scope.menuIcon = 'arrow_back';
        //    }
        //    else {
        //        $mdSidenav('left')
        //          .close();
        //        $scope.menuIcon = 'menu';
        //    }
        //}

        // controls sidebar expand/close
        //controll sidebar open & close in mobile and normal view
        $scope.sideBar = function (value) {
           // alert("sidebar");
            if ($(window).width() <= 767) {
                if ($("body").hasClass('sidebar-open'))
                    $("body").removeClass('sidebar-open');
                else
                    $("body").addClass('sidebar-open');
            }
            else {
                if (value == 1) {
                    if ($("body").hasClass('sidebar-collapse'))
                        $("body").removeClass('sidebar-collapse');
                    else
                        $("body").addClass('sidebar-collapse');
                }
            }
        };

    
       


        $scope.collapseVar = 0;
        $scope.check = function (x) {

            if (x == $scope.collapseVar)
                $scope.collapseVar = 0;
            else
                $scope.collapseVar = x;
        };

        $scope.collapseVar1 = 0;
        $scope.check1 = function (x) {

            if (x == $scope.collapseVar1)
                $scope.collapseVar1 = 0;
            else
                $scope.collapseVar1 = x;
        };

        $scope.collapseVar2 = 0;
        $scope.check2 = function (x) {

            if (x == $scope.collapseVar2)
                $scope.collapseVar2 = 0;
            else
                $scope.collapseVar2 = x;
        };

        $scope.collapseVar3 = 0;
        $scope.check3 = function (x) {

            if (x == $scope.collapseVar3)
                $scope.collapseVar3 = 0;
            else
                $scope.collapseVar3 = x;
        };

        $scope.collapseVar4 = 0;
        $scope.check4 = function (x) {

            if (x == $scope.collapseVar4)
                $scope.collapseVar4 = 0;
            else
                $scope.collapseVar4 = x;
        };


        $scope.collapseVar5 = 0;
        $scope.check5 = function (x) {

            if (x == $scope.collapseVar5)
                $scope.collapseVar5 = 0;
            else
                $scope.collapseVar5 = x;
        };
        


        //Added on  10/23/2017
        $scope.submitForm = function (isValid) {
            if (isValid) {
                alert('Your form has been successfully submitted!')
            }
        };
    }

})(angular.module('easychefdemo'));