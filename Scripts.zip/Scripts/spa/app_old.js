﻿(function () {
    'use strict';


    angular.module('easychefdemo', ['common.core', 'common.ui'])
        .config(config)
        .run(run);

    //config.$inject = ['$stateProvider', '$urlRouterProvider', '$cookiesProvider', '$mdThemingProvider',
    //                '$mdIconProvider'];

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$cookiesProvider'   ];
    function config($stateProvider, $urlRouterProvider, $cookiesProvider) {
        $urlRouterProvider.otherwise('/');

        
        $stateProvider
            .state('home', {
                url: '/',
                templateUrl: '/scripts/spa/home/index.html',
                authenticate: false

            })

            .state('login', {
                url: '/login',
                templateUrl: '/scripts/spa/account/login.html',
                controller: 'loginCtrl',
                authenticate: false
                
            })
            .state('register', {
                url: '/register',
                templateUrl: '/scripts/spa/account/register.html',
                controller: 'restaurantRegisterCtrl',
                authenticate: false
                
            })

             .state('Management', {
                 url: '/Management',
                 templateUrl: '/scripts/spa/layout/main.html',
                 authenticate: true
                 //resolve: { isAuthenticated: isAuthenticated }
                
             })

            .state('Management.recipies', {
                url: '/recipies',
                templateUrl: '/scripts/spa/recipies/recipies.html',
                controller: 'recipiesCtrl',
                authenticate: true
                //resolve: { isAuthenticated: isAuthenticated }
             
            })

            .state('Management.recipiesadd', {
                url: '/add',
                templateUrl: '/scripts/spa/recipies/recipieAdd.html',
                authenticate: true
                //resolve: { isAuthenticated: isAuthenticated }
             
            })

            .state('Management.recipies.edit', {
                url: '/Management/recipies/edit/{recipieId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/recipies/recipieAdd.html',
                authenticate: true
                //resolve: { isAuthenticated: isAuthenticated }
            
            })

            .state('Management.recipies.detail', {
                url: '/Management/recipies/detail/{recipieId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/recipies/recipieAdd.html',
                authenticate: true
                //resolve: { isAuthenticated: isAuthenticated }
              
            })

            .state('Management.inventoryitem', {
                url: '/inventoryitems',
                templateUrl: '/scripts/spa/inventoryitems/inventoryitems.html',
               // controller: 'recipiesCtrl',
                authenticate: true
                //resolve: { isAuthenticated: isAuthenticated }

            })

         .state('Management.inventoryitemadd', {
             url: '/inventoryitemsadd',
             templateUrl: '/scripts/spa/inventoryitems/inventoryitemAdd.html',
             controller: 'inventoryItemAddCtrl',
             authenticate: true
             //resolve: { isAuthenticated: isAuthenticated }

         })



    //  $mdThemingProvider.theme('default')
    //  .primaryPalette('cyan', {
    //      'default': '400', // by default use shade 400 from the cyan palette for primary intentions
    //      'hue-1': '100', // use shade 100 for the <code>md-hue-1</code> class
    //      'hue-2': '600', // use shade 600 for the <code>md-hue-2</code> class
    //      'hue-3': 'A100' // use shade A100 for the <code>md-hue-3</code> class
    //  })
    //  .accentPalette('amber')
    //  .warnPalette('red')
    //.backgroundPalette('grey');


    //    $mdThemingProvider.theme('default')
    //  .primaryPalette('cyan', {
    //      'default': '400', // by default use shade 400 from the cyan palette for primary intentions
    //      'hue-1': '100', // use shade 100 for the <code>md-hue-1</code> class
    //      'hue-2': '600', // use shade 600 for the <code>md-hue-2</code> class
    //      'hue-3': 'A100' // use shade A100 for the <code>md-hue-3</code> class
    //  })
    //  .accentPalette('amber')
    //  .warnPalette('red')
    //.backgroundPalette('grey');


    }

    run.$inject = ['$rootScope', '$location', '$cookies', '$http','$state','membershipService' ];

    function run($rootScope, $location, $cookies, $http, $state, membershipService) {
       // alert($cookies.get('repository'));
        // handle page refreshes
        $rootScope.repository = $cookies.get('repository') || {};
        if ($rootScope.repository.loggedUser) {
            $http.defaults.headers.common['Authorization'] = $rootScope.repository.loggedUser.authdata;
            
        }


        $(document).ready(function () {
            //alert("jquery loaded");
            $(".fancybox").fancybox({
                openEffect: 'none',
                closeEffect: 'none'
            });

            $('.fancybox-media').fancybox({
                openEffect: 'none',
                closeEffect: 'none',
                helpers: {
                    media: {}
                }
            });

            $('[data-toggle=offcanvas]').click(function () {
                alert("cliclk");
                $('.row-offcanvas').toggleClass('active');
            });
        });

       // alert("run");
        //$rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {

           
        ////    alert("state Change");
        //    // if (toState.authenticate && !membershipService.isUserLoggedIn()) {
        //    if (toState.authenticate && !membershipService.isUserLoggedIn()) {
        //        // User isn’t authenticated
        //        $rootScope.repository = $cookies.get('repository') || {};
        //        if ($rootScope.repository.loggedUser) {
        //            $http.defaults.headers.common['Authorization'] = $rootScope.repository.loggedUser.authdata;

        //        }
        //        // alert("in2" + $rootScope.repository.loggedUser.authdata);
        //        if ($cookies.get('repository') == undefined) {
        //            $rootScope.previousState = $location.path();
        //            $state.transitionTo("login");
        //            event.preventDefault();
        //        }
        //    }
        //});


        $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {


          //  alert("state-Change");
         //   var user = $rootScope.repository.loggedUser.username;
         //   alert("user " +user);
         //   alert("undefined");
              if (toState.authenticate && typeof $rootScope.repository.loggedUser.username === 'undefined') {
             // alert("in2" + $rootScope.repository.loggedUser.authdata);
                  // if ($cookies.get('repository') == undefined) {
                  alert("inside");
                    $rootScope.previousState = $location.path();
                    $state.go("login");
                    event.preventDefault();
               // }
            }


        




        });








    }

    //isAuthenticated.$inject = ['membershipService', '$rootScope', '$location',' $state'];

    //function isAuthenticated(membershipService, $rootScope, $location, $state) {
    //    alert("check -auth");

    //    $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
    //        alert("in");

    //        if (!membershipService.isUserLoggedIn()) {
    //            // User isn’t authenticated
    //            alert("User isn’t authenticated");
    //            $state.transitionTo('login');
    //            event.preventDefault();
    //        }
    //    });
    //    //if (!membershipService.isUserLoggedIn()) {
    //    //    $rootScope.previousState = $location.path();
    //    //    $location.path('login');
    //    //}
    //}

})();