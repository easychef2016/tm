﻿(function (app) {
    'use strict';

    app.controller('unitDetailsCtrl', unitDetailsCtrl);

    unitDetailsCtrl.$inject = ['$scope', 'apiService', 'notificationService'];

    function unitDetailsCtrl($scope, apiService, notificationService) {
        //alert("unit");
        // $scope.pageClass = 'page-home';
        $scope.loadingunits = true;
        $scope.isReadOnly = true;

        $scope.latestunits = [];
        $scope.selectedunit = {};


        $scope.loadData = loadData;

        //below var declared for edit/update/cancel
        $scope.newUnits = [];
        $scope.editing = false;

        $scope.getStatusColor = getStatusColor;
        $scope.getStatustext = getStatustext;

        function getStatusColor(status) {
           
            if (status == 'True' || status == true)
                return 'green'
            else {
                return 'red';
            }
        }

       

        function getStatustext(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'Active';
            else {
                return 'In Active';
            }
        }



        function loadData() {
            apiService.get('/api/units/latest', null,
                       unitsLoadCompleted,
                        unitsLoadFailed);

        }

        function unitsLoadCompleted(result) {

            $scope.latestunits = result.data;
            $scope.loadingunits = false;
        }

        function unitsLoadFailed(response) {

            notificationService.displayError(response.data);
        }

        $scope.editUnit = function (unit) {
            //alert(category.Status);
            $scope.editing = $scope.latestunits.indexOf(unit);
            $scope.newUnits[$scope.editing] = angular.copy(unit);


        };

        $scope.updateUnit = function (unit) {
            //alert(unit.ID);
            //alert(unit.Name);
            $scope.selectedunit = angular.copy(unit);
            apiService.post('/api/units/update', unit,
               updateUnitSucceded,
               updateUnitFailed);
        };


        $scope.cancel = function (index) {

            //if ($scope.editing !== false) {
            $scope.latestunits[$scope.editing] = $scope.newUnits[index];
            $scope.editing = false;
            //}
        };


        function updateUnitSucceded(response) {
            console.log(response);
            notificationService.displaySuccess($scope.selectedunit.Name + ' has been updated');
            loadData();

        }

        function updateUnitFailed(response) {
            notificationService.displayError(response);
        }




        loadData();
    }

})(angular.module('easychefdemo'));