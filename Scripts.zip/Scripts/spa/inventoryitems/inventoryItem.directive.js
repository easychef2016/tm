﻿(function (app) {
    'use strict';

    app.directive('inventoryItem', inventoryItem);

    function inventoryItem() {
        return {
            restrict: 'E',
            scope: {},
            templateUrl: '/scripts/spa/inventoryitems/dynamicInventoryItem.html',
            controller: function ($rootScope, $scope, $element) {
                //$scope.contacts = $rootScope.GetContactTypes;
                $scope.Delete = function (e) {
                    //remove element and also destoy the scope that element
                    $element.remove();
                    $scope.$destroy();
                }
            }
        }
    }

})(angular.module('common.ui'));