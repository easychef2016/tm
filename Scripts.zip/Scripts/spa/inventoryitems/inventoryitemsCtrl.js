﻿(function (app) {
    'use strict';

    app.controller('inventoryItemsCtrl', inventoryItemsCtrl);

    inventoryItemsCtrl.$inject = ['$scope', 'apiService', 'notificationService', '$mdToast', '$rootScope', '$mdDialog' ];

    function inventoryItemsCtrl($scope, apiService, notificationService, $mdToast, $rootScope, $mdDialog) {
        //alert("inventoryItemsCtrl");
        // $scope.pageClass = 'page-home';
        $scope.loadinginventoryItems = true;
        //$scope.loadingGenres = true;
        $scope.isReadOnly = true;

        $scope.latestinventoryItems = [];
        $scope.loadData = loadData;
        $scope.getStatustext = getStatustext;
        $scope.inventoryIndex = '';
        $scope.InventoryItemViewModel = {
            ID: '',
            Name:''
        };



        //

       //  $rootScope.repository = {
       //       loggedUser: {
      //            username:'',
       //           authdata: ''
       //        }
        //   };

       //  $rootScope.repository = $cookies.getObject('repository') || {};

        $scope.deleteRowCallback = function (rows) {
            $mdToast.show(
                $mdToast.simple()
                    .content('Deleted row id(s): ' + rows)
                    .hideDelay(3000)
            );
        };


        function getStatustext(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'Active';
            else {
                return 'In Active';
            }
        }
        
        function loadData() {
            //alert($rootScope.repository.loggedUser.username);
           // alert("load");
            apiService.get('/api/inventoryitems/latest', null,
                       inventoryItemsLoadCompleted,
                        inventoryItemsLoadFailed);
           // alert("load");
            //apiService.get("/api/genres/", null,
            //    genresLoadCompleted,
            //    genresLoadFailed);
        }

        function inventoryItemsLoadCompleted(result) {
           // alert("completed");

            $scope.latestinventoryItems = result.data;
            //alert($scope.latestinventoryItems);
            $scope.loadinginventoryItems = false;
        }

        //function genresLoadFailed(response) {
        //    notificationService.displayError(response.data);
        //}

        function inventoryItemsLoadFailed(response) {
           // alert("error");
           // debugger;
           // alert(response.data);
            notificationService.displayError(response.data);
        }


        $scope.cancel = function (index) {
           // alert(index);
            $scope.inventoryIndex = index;
            var itemid = $scope.latestinventoryItems[this.$index].ID;
            var itemname = $scope.latestinventoryItems[this.$index].Name;
            $scope.InventoryItemViewModel = {
                ID:$scope.latestinventoryItems[this.$index].ID,
                Name :itemname = $scope.latestinventoryItems[this.$index].Name
            }
           
           var delConfirm = confirm("Are you sure you want to delete the Inventory item " + itemname + " ?");
          
           if (delConfirm == true) {
               $scope.latestinventoryItems.splice(index, 1);
               apiService.post('/api/inventoryitems/delete', $scope.InventoryItemViewModel,
                deleteinventoryItemSucceded,
                deleteinventoryItemFailed);
            }
        };

        function deleteinventoryItemSucceded(response) {
            notificationService.displaySuccess('Inventory Item has been deleted,please referesh screen for the changes');
            $scope.latestinventoryItems = response.data;
                 
          
        }

        function deleteinventoryItemFailed(response) {
            console.log(response);
            notificationService.displayError(response.data);
           
        }


       

        loadData();



















    }

})(angular.module('easychefdemo'));