﻿(function (app) {
    'use strict';

    app.directive('ngAddressAutocomplete', ngAddressAutocomplete);

    function ngAddressAutocomplete() {

        var componentForm = {
            premise: 'long_name',
            street_number: 'short_name',
            route: 'long_name',
            sublocality_level_1: 'long_name',
            locality: 'long_name',
            administrative_area_level_1: 'short_name',
            country: 'long_name',
            postal_code: 'short_name'
        };

        return {
            restrict: "EA",
            scope: {
                ngModel:"=",
                city: "=",
                address:"=",
                zipCode:"=",
                country:"=",
                streetName:"=",
                streetNumber: "=",
                state:"=",
                lat: "=",
                lng:"="
            },
            link: function (scope, element, attrs) {
             
                var autocomplete = new google.maps.places.Autocomplete(element[0]);
                // google.maps.event.addListener(autocomplete, 'place_changed', function() {  
                google.maps.event.addListener(autocomplete, 'place_changed', function () {
                    var place = autocomplete.getPlace();

                    var location = autocomplete.getPlace().geometry.location;
                    scope.lat = location.lat();
                    scope.lng = location.lng();


                    if (!scope.$$phase) scope.$apply(function(){
                        var componenents = place.address_components || [];

                        var components = place.address_components;  // from Google API place object   

                        scope.address = components[0].short_name + " " + components[1].short_name;
                        scope.city = components[3].short_name;
                        scope.state = components[5].short_name;
                        scope.country = components[6].long_name;
                        scope.zipCode = components[7].short_name;

                        /*for (var i = 0; i < componenents.length; i++) {
                            var item = componenents[i];
                           
                            if(item&&item.types){
                                if(/route/gi.test(item.types[0])){
                                    scope.streetName =componenents[1].long_name;
                                }
                                if(/country/gi.test(item.types[0])){
                                    scope.country =item.long_name;
                                }
                                if(/street_number/gi.test(item.types[0])){
                                    scope.streetNumber =item.long_name;
                                }
                                if(/postal_code/gi.test(item.types[0])){
                                    scope.zipCode =item.long_name;
                                }

                                if (/locality|city/gi.test(item.types[0])) {   //city
                                    scope.city =item.long_name;
                                }

                                if (/administrative_area_level_1|city/gi.test(item.types[0])) {   //state
                                    scope.state =item.long_name;
                                }

                                scope.address = scope.streetNumber + " " + scope.streetName
                            }
                        }*/


                    });                        
                })
            }
        }
        
    }

})(angular.module('common.core'));