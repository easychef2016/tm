﻿(function (app) {
    'use strict';

    app.controller('datepickerCtrl', datepickerCtrl);

    datepickerCtrl.$inject = ['$scope'];

    function datepickerCtrl($scope) {

        $('.date').datepicker({ autoclose: true, todayHighlight: true });
        var inputDate = new Date(moment($scope.value));
        $scope.value = moment(inputDate).format("DD-MM-YYYY");
        $('.date').datepicker('setDate', inputDate);
        $scope.$watch('value', function (newVal) {
        });

    }

})(angular.module('common.core'));