﻿(function (app) {
    'use strict';

    app.directive('datePicker', datePicker);

    function datePicker() {
        alert("date");
        return {
            restrict: 'A',
            controller: 'datepickerCtrl',
            controllerAs: 'dp',
            templateUrl: '/Scripts/spa/components/datepicker.html',
            scope: {
                'value': '='
            },
            link: function (scope, element, attribute) {
            }
        };
    }

})(angular.module('common.ui'));