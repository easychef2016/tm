﻿(function (app) {
    'use strict';

    app.directive('myDatepicker', myDatepicker);

    function myDatepicker() {
       
        return {
            require: 'ngModel',
           
            link: function (scope, element, attrs, ngModelCtrl) {
                $(function () {
                    $(element).datepicker({
                        restrict: 'A',
                        inline: true,
                        changeYear: false,
                        changeMonth: false,
                        dateFormat: 'mm/dd/yy',
                        onSelect: function (dateText, inst) {

                            ngModelCtrl.$setViewValue(dateText);
                            scope.$apply();
                        }

                    });


                });
            }
        }
    }

})(angular.module('common.core'));