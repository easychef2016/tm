﻿angular.module('ngMapModule', [])
  .directive('ngAddressAutocomplete', function () {
    return {
        restrict: "EA",
        scope: {
            ngModel:"=",
            city:"=",
            zipCode:"=",
            country:"=",
            streetName:"=",
            streetNumber:"="
        },
        link: function (scope, element, attrs) {
          
            var autocomplete = new google.maps.places.Autocomplete(element[0]);
            // google.maps.event.addListener(autocomplete, 'place_changed', function() {  
            google.maps.event.addListener(autocomplete, 'place_changed', function () {
                var place = autocomplete.getPlace();  
                
                if (!scope.$$phase) scope.$apply(function(){
                    var componenents=place.address_components||[];
                    for(var i=0;i<componenents.length;i++){
                        var item=componenents[i];
                        if(item&&item.types){
                            if(/route/gi.test(item.types[0])){
                                scope.streetName =componenents[1].long_name;
                            }
                            if(/country/gi.test(item.types[0])){
                                scope.country =item.long_name;
                            }
                            if(/street_number/gi.test(item.types[0])){
                                scope.streetNumber =item.long_name;
                            }
                            if(/postal_code/gi.test(item.types[0])){
                                scope.zipCode =item.long_name;
                            }
                            if(/dministrative_area_level_2|city/gi.test(item.types[0])){
                                scope.city =item.long_name;
                            }
                        }
                    }
                });                        
            })
        }
    }
})

