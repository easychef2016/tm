﻿(function (app) {
    'use strict';

    app.controller('InventoryInvoiceCtrl', InventoryInvoiceCtrl);

    InventoryInvoiceCtrl.$inject = ['$scope', '$location', '$stateParams', 'apiService', 'notificationService','$rootScope'];

    function InventoryInvoiceCtrl($scope, $location, $stateParams, apiService, notificationService, $rootScope) {

        //  $scope.pageClass = 'page-InventoryItems';
        //alert("Invoice Edit : " + $stateParams.id);




        $scope.submitted = false;
        $scope.submitting = false;
        $scope.currentdate = new Date();
        $scope.currentID = $stateParams.id;

        $scope.loadingInventoryInvoice = true;
        $scope.InventoryInvoice = [];

        $scope.latestRecipies = [];

        $scope.sendEmail = sendEmail;

        $scope.loadUserdata = loadUserdata;

        //Restaurant Details
        $scope.restaurantdetails = {};
        $scope.loadrestaurantdetails = loadrestaurantdetails;
        $scope.loadvendordetails = loadvendordetails;
        $scope.vendordetails = {};

        $scope.vendorinfo= [];



        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;

            }
        }

        function loadrestaurantdetails() {
            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };
            //alert($scope.filterUsername);
            apiService.get('/api/restaurant/details/', config,
            loadrestaurantdetailsCompleted,
            loadrestaurantdetailsFailed);
        }


        function loadrestaurantdetailsCompleted(response) {

            $scope.restaurantdetails = response.data;
        }

        function loadrestaurantdetailsFailed(response) {
            console.log(response);
            //notificationService.displayError(response.statusText);
        }

        function loadvendordetails() {
            var config = {
                params: {

                    filter: $stateParams.id
                }
            };

            apiService.get('/api/vendors/vendordetails/', config,
            loadvendordetailsCompleted,
            loadvendordetailsFailed);
        }


        function loadvendordetailsCompleted(response) {

            $scope.vendordetails = response.data;
        }

        function loadvendordetailsFailed(response) {
            console.log(response);
            // notificationService.displayError(response.statusText);
        }


        function loadInventoryInvoice() {


            var config = {
                params: {
                    inventoryId: $stateParams.id,
                    filterUsername: $scope.filterUsername
                }
            };
            $scope.loadingInventoryInvoice = true;

            // apiService.get('/api/inventories/invoicedetails/' + $stateParams.id , null,
            apiService.get('/api/inventories/invoicedetails/', config,
            InventoryInvoiceLoadCompleted,
            InventoryInvoiceLoadFailed);

        }

        function InventoryInvoiceLoadCompleted(response) {
            //alert(response.data);
            debugger;
            $scope.InventoryInvoice = response.data;

            $scope.vendorinfo = $scope.InventoryInvoice[2].Vendor;
            //alert($scope.InventoryInvoice.ID);
            $scope.loadingInventoryInvoice = false;


        }

        function InventoryInvoiceLoadFailed(response) {

            notificationService.displayError(response.statusText);


        }




        function sendEmail() {

            // alert("email send");
            apiService.post('/api/inventories/sendemail/' + $stateParams.id, null,
                sendEmailSucceded,
                sendEmailFailed);




        }


        function sendEmailSucceded(response) {
            notificationService.displaySuccess('Email has been sent');


        }

        function sendEmailFailed(response) {
            console.log(response);

            notificationService.displayError(response.statusText);
        }


        // Print function 

        $scope.printInvoice = function (printSectionId) {


            var innerContents = document.getElementById(printSectionId).innerHTML;
            var popupWinindow = window.open('', '_blank', 'width=600,height=700,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
            popupWinindow.document.open();
            popupWinindow.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title>ManagePad | Invoice</title><link href="../../../Content/css/bootstrap.min.css" rel="stylesheet" /><link href="../../../Content/css/dashboard.css" rel="stylesheet" /><meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"></head><body onload="window.print()"><div class="wrapper"><section  class="invoice">' + innerContents + '</section></div></body></html>');
            popupWinindow.document.close();
        }



        loadUserdata();
        loadrestaurantdetails();
       // loadvendordetails();
        loadInventoryInvoice();


    };

    //app.filter('groupby', function () {
    //    return function (items, group) {
    //        return items.filter(function (element, index, array) {
    //            return parseInt(element.time) == group;
    //        });
    //    }
    //});

})(angular.module('easychefdemo'));