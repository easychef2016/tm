﻿(function (app) {
    'use strict';

    app.controller('inventoryAddCtrl', inventoryAddCtrl);

    inventoryAddCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService','$rootScope'];

    function inventoryAddCtrl($scope, $location, $timeout, apiService, notificationService, $rootScope) {

        $scope.isReadOnly = false;
        $scope.AddInventoryModel = AddInventoryModel;
       
        $scope.submitted = false;
        $scope.submitting = false;

        $scope.inventory = {
            Name: '',
            Status: true,
            InventoryDate: '',
            loginUserInfo :''
        };


        $scope.loadUserdata = loadUserdata;

        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;
                $scope.inventory.loginUserInfo = $scope.filterUsername;

            }
        }


       
        function AddInventoryModel() {
            $scope.submitted = true;
            if ($scope.addInventoryForm.$valid) {
                $scope.submitting = true;
               
                apiService.post('/api/inventories/add', $scope.inventory,
                addInventorySucceded,
                addInventoryFailed);

            }
           
         
        }
             

        function addInventorySucceded(response) {
            notificationService.displaySuccess($scope.inventory.Name + ' has been submitted to ManagePad');
            $scope.inventory = response.data;
            redirectToEdit();
        }

        function addInventoryFailed(response) {
            console.log(response);
            
            notificationService.displayError(response.statusText);
        }



        function redirectToEdit() {
            $location.url('Management/inventoryEdit/' + $scope.inventory.ID);

            
        }

        loadUserdata();
        

    }

})(angular.module('easychefdemo'));