﻿(function (app) {
    'use strict';

    app.controller('inventoryEditCtrl', inventoryEditCtrl);

    inventoryEditCtrl.$inject = ['$scope', '$location', '$stateParams', 'apiService', 'notificationService','$rootScope'];

    function inventoryEditCtrl($scope, $location, $stateParams, apiService, notificationService, $rootScope) {

        //  $scope.pageClass = 'page-InventoryItems';
        //alert("Inventory Edit : " + $stateParams.id);
        $scope.categories = [];
        $scope.units = [];
        $scope.vendors = [];

        $scope.addinventory = addinventory;
        $scope.DeleteInventoryItem = DeleteInventoryItem;

        $scope.submitted = false;
        $scope.submitting = false;
      


        $scope.loadingInventories= true;
        $scope.Inventory = {};
        $scope.inventorysheetVm = {};



        $scope.filterUsername = '';
        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;

            }
        }
       

        $scope.UpdateInventorySheetModel = UpdateInventorySheetModel;

        function loadvendors() {

            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };
            apiService.get('/api/vendors/latest', config,
            vendorsLoadCompleted,
            vendorsLoadFailed);
        }

        function vendorsLoadCompleted(response) {
            $scope.vendors = response.data;
        }

        function vendorsLoadFailed(response) {
            notificationService.displayError(response.data);
        }

        //---TYPEAHEAD SEARCH - STARTS 
        $scope.selectInventoryItem = selectInventoryItem;
        $scope.selectionChanged = selectionChanged;
        // $scope.selectedtInventoryItem = -1;
        $scope.selectedtInventoryItem = [];
        $scope.isEnabled = false;
        $scope.VendorName = '';

        function selectInventoryItem($item) {
            if ($item) {

                $scope.inventory.ApprovedInventories[this.$parent.$index].InventoryItemId = $item.originalObject.ID;
                $scope.inventory.ApprovedInventories[this.$parent.$index].Quantity = $item.originalObject.Quantity;
                $scope.inventory.ApprovedInventories[this.$parent.$index].Price = $item.originalObject.Price;
                $scope.inventory.ApprovedInventories[this.$parent.$index].Vendor = $item.originalObject.Vendor;
                $scope.inventory.ApprovedInventories[this.$parent.$index].Category = $item.originalObject.Category;
                $scope.inventory.ApprovedInventories[this.$parent.$index].CategoryId = $item.originalObject.CategoryId;
              //  $scope.inventory.ApprovedInventories[this.$parent.$index].VendorId = $item.originalObject.VendorId;
             //   $scope.VendorName = $item.originalObject.Vendor;

                //$scope.inventory.approvedinventoryItems.InventoryItemId = $item.originalObject.ID;
                //$scope.inventory.approvedinventoryItems.Quantity = $item.originalObject.Quantity;
                //$scope.inventory.approvedinventoryItems.Price = $item.originalObject.Price;
                //$scope.inventory.approvedinventoryItems.Vendor = $item.originalObject.Vendor;
                //$scope.inventory.approvedinventoryItems.Category = $item.originalObject.Category;
                $scope.isEnabled = true;
            }
            else {
                $scope.selectedtInventoryItem = null;
                $scope.isEnabled = false;
            }
        }

        function selectionChanged($item) {
        }


        ////TYPEAHEAD SEARCH ENDS....

        $scope.inventory = {

            ApprovedInventories: [{
                InventoryItemId: '',
                Quantity: null,
                Price: '',
                ParValue: '',
                MinOrder: '',
                Order: '',
                Category :'',
               
            }]
        };


        function addinventory() {

            $scope.inventory.ApprovedInventories.push(
            {
                InventoryItemId: '',
                Quantity: null,
                Price: '',
                ParValue: '',
                MinOrder: '',
                Order: '',
                Category: '',

            });
        }


        function DeleteInventoryItem(index) {

            var itemid = $scope.inventory.ApprovedInventories[this.$index].InventoryItemId;
            var itemname = $scope.inventory.ApprovedInventories[this.$index].InventoryId;

           // alert(itemid);
           // alert(itemname);

            $scope.inventory.ApprovedInventories.splice(index, 1);
        }

        

        function UpdateInventorySheetModel() {

          
            $scope.submitted = true;

            if ($scope.InventorySheetEditForm.$valid) {
                $scope.submitting = true;
                
                $scope.inventory.ID = angular.copy($scope.inventoryresponse.ID);
              //  alert($scope.VendorName);
                $scope.inventory.Vendor = angular.copy($scope.VendorName);

                
                $scope.inventorysheetVm = angular.copy($scope.inventory);
                               
                apiService.post('/api/inventories/update', $scope.inventory,
                    UpdateInventorySheetModelSucceded,
                    UpdateInventorySheetModelFailed);
             }
          }


        function UpdateInventorySheetModelSucceded(response) {
            notificationService.displaySuccess('Inventory Item has been submitted ');
            $scope.submitting = false;
        
            redirectToEdit();
        }

        function UpdateInventorySheetModelFailed(response) {
            console.log(response);
            notificationService.displayError(response.data);
            $scope.submitting = false;
            

        }

        function redirectToEdit() {
          
            $location.url('Management/inventoryinvoice/' + $scope.inventory.ID);


        }

                

       


        function loadInventory() {

            $scope.loadingInventories = true;
            // apiService.get('/api/inventories/details/' + $stateParams.id, null,

            apiService.get('/api/inventories/detailsedit/' + $stateParams.id, null,
            inventoryLoadCompleted,
            inventoryLoadFailed);



        }
        

        function inventoryLoadCompleted(response) {
            $scope.inventoryresponse = response.data;
            $scope.loadingInventories = false;
            $scope.inventory = response.data;
            loadvendors();
            //alert($scope.inventory.InventoryDate);
            //alert(response.data.length);
        }

        function inventoryLoadFailed(response) {

            notificationService.displayError(response.data);
            $scope.submitting = false;
            $scope.inventory = {

                approvedinventoryItems: [{
                    ItemID: '',
                    Quantity: null,
                    Price: '',
                    Vendor: '',
                    TotalValue: ''
                }]
            };
        }


        function UpdateinventoryModel() {
            // alert("update ")
            $scope.submitted = true;

            if ($scope.InventorySheetEditForm.$valid) {
                $scope.submitting = true;
                apiService.post('/api/inventoryitems/update', $scope.InventoryItem,
                updateinventorySucceded,
                updateinventoryFailed);
            }
        }



        function updateinventorySucceded(response) {
          
            notificationService.displaySuccess($scope.Inventory.Name + ' has been updated');
            $scope.Inventory= response.data;
            // movieImage = null;
        }

        function updateinventoryFailed(response) {
            console.log(response);
            notificationService.displayError(response.statusText);
        }


        function loadingredients() {
            apiService.get('/api/inventoryitems/latest', null,
                       ingredientsLoadCompleted,
                        ingredientsLoadFailed);

        }

        function ingredientsLoadCompleted(result) {
            $scope.selectedtInventoryItem = result.data;
            // $scope.loadinginventoryItems = false;
        }

        function ingredientsLoadFailed(response) {
            notificationService.displayError(response.data);
        }
       
        loadUserdata();
        loadInventory();
        loadingredients();
        addinventory();





    }

})(angular.module('easychefdemo'));