﻿(function (app) {
    'use strict';

    app.controller('inventoryDetailsCtrl', inventoryDetailsCtrl);

    inventoryDetailsCtrl.$inject = ['$scope', 'apiService', 'notificationService','$rootScope'];

    function inventoryDetailsCtrl($scope, apiService, notificationService, $rootScope) {
       
        // $scope.pageClass = 'page-home';
        $scope.loadinginventories = true;
        $scope.filterUsername = '';
     
        $scope.isReadOnly = true;

        $scope.latestinventories = [];
        $scope.loadData = loadData;
        $scope.loadUserdata = loadUserdata;

        $scope.getStatustext = getStatustext;
        function getStatustext(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'Active';
            else {
                return 'In Active';
            }
        }

        $scope.getStatustextVendor = getStatustextVendor;
        function getStatustextVendor(status) {
            // alert("test");
            if (status == 1 )
                return 'Submitted to Vendor';
            else {
                return 'Created';
            }
        }


      

        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;

            }
        }

        function loadData() {
            //Added to pass user information : added on 08/13
        //    alert("user name");
        //    alert($scope.filterUsername);
            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };

            apiService.get('/api/inventories/latest/', config,
                       inventoryItemsLoadCompleted,
                        inventoryItemsLoadFailed);
         
        }

        function inventoryItemsLoadCompleted(result) {
            // alert("completed");

            $scope.latestinventories = result.data;
            //alert($scope.latestinventoryItems);
            $scope.loadinginventories = false;
        }

        //function genresLoadFailed(response) {
        //    notificationService.displayError(response.data);
        //}

        function inventoryItemsLoadFailed(response) {
            // alert("error");
            // debugger;
            // alert(response.data);
            notificationService.displayError(response.data);
        }

        $scope.inventoryIndex = '';

        $scope.InventorySheetViewModel = {
            ID: '',
            Name: ''
        };

        $scope.cancel = function (index) {
            // alert(index);

            var itemid = $scope.latestinventories[this.$index].ID;
            var itemname = $scope.latestinventories[this.$index].Name;
            $scope.inventoryIndex = index;


            $scope.InventorySheetViewModel = {
                ID: $scope.latestinventories[this.$index].ID,
                Name: itemname = $scope.latestinventories[this.$index].Name
            }

            var delConfirm = confirm("Are you sure you want to delete the Inventory sheet " + itemname + " ?");

            if (delConfirm == true) {
                $scope.latestinventories.splice(index, 1);
                apiService.post('/api/inventories/delete', $scope.InventorySheetViewModel,
                 deleteinventorySheetSucceded,
                 deleteinventorySheetFailed);
            }
        };

        function deleteinventorySheetSucceded(response) {
            notificationService.displaySuccess('Inventory sheet has been deleted,Please referesh screen for the changes');
            $scope.latestinventories = response.data;
            
        }

        function deleteinventorySheetFailed(response) {
            console.log(response);
            notificationService.displayError(response.data);

        }


        loadUserdata();
        loadData();
      
    }

})(angular.module('easychefdemo'));