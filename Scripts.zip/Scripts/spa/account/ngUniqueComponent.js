﻿(function (app) {
    'use strict';

    app.directive('ngUnique', ['$http', function (async) {
        return {
            require: 'ngModel',
            link: function (scope, elem, attrs, ctrl) {

                elem.on('blur', function (evt) {
                    scope.$apply(function () {
                        var val = elem.val();
                        var req = { "userName": val }
                        var ajaxConfiguration = { method: 'POST', url: 'IsUserAvailable', data: req };
                        async(ajaxConfiguration)
                            .success(function (data, status, headers, config) {
                                ctrl.$setValidity('unique', data.result);
                            });
                    });
                });
            }
        }
    }]);

})(angular.module('common.core'));