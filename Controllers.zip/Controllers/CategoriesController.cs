﻿using AutoMapper;
using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EasyChefDemo.Web.Infrastructure.Extensions;
using EasyChefDemo.Web.Infrastructure.Filters;
namespace EasyChefDemo.Web.Controllers
{

     [DeflateCompression]
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/categories")]
    public class CategoriesController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Category> _categoriesRepository;

        public CategoriesController(IEntityBaseRepository<Category> categoriesRepository,
             IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _categoriesRepository = categoriesRepository;
        }

        [AllowAnonymous]
        public HttpResponseMessage Get(HttpRequestMessage request, string filter)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var categories = _categoriesRepository.GetAll().ToList();

                IEnumerable<CategoryViewModel> categoriesVM = Mapper.Map<IEnumerable<Category>, IEnumerable<CategoryViewModel>>(categories);

                response = request.CreateResponse<IEnumerable<CategoryViewModel>>(HttpStatusCode.OK, categoriesVM);

                return response;
            });
        }


        [AllowAnonymous]
        [Route("latest")]
        [CacheFilter(TimeDuration = 100)]  
        public HttpResponseMessage Get(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                
                var categories = _categoriesRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();

                IEnumerable<CategoryViewModel> categoriesVM = Mapper.Map<IEnumerable<Category>, IEnumerable<CategoryViewModel>>(categories);
                response = request.CreateResponse<IEnumerable<CategoryViewModel>>(HttpStatusCode.OK, categoriesVM);

                return response;
            });
        }



        [HttpPost]
        [Route("add")]
        public HttpResponseMessage Add(HttpRequestMessage request, List<Category> categoriesList)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    Category newcategorytem = new Category();
                 

                    if (categoriesList != null)
                    {
                        foreach (var category in categoriesList)
                        {


                            newcategorytem.UpdateCategoryItem(category);

                            _categoriesRepository.Add(newcategorytem);

                            _unitOfWork.Commit();
                        }
                    }


                    response = request.CreateResponse(HttpStatusCode.OK, new { success = true });



                  
                }

                return response;
            });
        }




        [HttpPost]
        [Route("update")]
        public HttpResponseMessage Update(HttpRequestMessage request, CategoryViewModel categoryItem)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    var categorytemDb = _categoriesRepository.GetSingle(categoryItem.ID);
                    if (categorytemDb == null)
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid categoryItem.");
                    else
                    {
                        categorytemDb.UpdateCategoryItemEdit(categoryItem);
                        _categoriesRepository.Edit(categorytemDb);

                        _unitOfWork.Commit();
                        response = request.CreateResponse<CategoryViewModel>(HttpStatusCode.OK, categoryItem);
                    }
                }

                return response;
            });
        }

    }



     [Authorize(Roles = "Admin")]
     [RoutePrefix("mobileapi/categories")]
     public class MobileCategoriesController : ApiControllerBase
     {
         private readonly IEntityBaseRepository<Category> _categoriesRepository;

         public MobileCategoriesController(IEntityBaseRepository<Category> categoriesRepository,
              IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
             : base(_errorsRepository, _unitOfWork)
         {
             _categoriesRepository = categoriesRepository;
         }

         [AllowAnonymous]
         public HttpResponseMessage Get(HttpRequestMessage request, string filter)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 var categories = _categoriesRepository.GetAll().ToList();

                 IEnumerable<CategoryViewModel> categoriesVM = Mapper.Map<IEnumerable<Category>, IEnumerable<CategoryViewModel>>(categories);

                 response = request.CreateResponse<IEnumerable<CategoryViewModel>>(HttpStatusCode.OK, categoriesVM);

                 return response;
             });
         }


         [AllowAnonymous]
         [Route("latest")]
         [CacheFilter(TimeDuration = 100)]
         public HttpResponseMessage Get(HttpRequestMessage request)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var categories = _categoriesRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();

                 IEnumerable<CategoryViewModel> categoriesVM = Mapper.Map<IEnumerable<Category>, IEnumerable<CategoryViewModel>>(categories);
                 response = request.CreateResponse<IEnumerable<CategoryViewModel>>(HttpStatusCode.OK, categoriesVM);

                 return response;
             });
         }



         [HttpPost]
         [Route("add")]
         public HttpResponseMessage Add(HttpRequestMessage request, List<Category> categoriesList)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     Category newcategorytem = new Category();


                     if (categoriesList != null)
                     {
                         foreach (var category in categoriesList)
                         {


                             newcategorytem.UpdateCategoryItem(category);

                             _categoriesRepository.Add(newcategorytem);

                             _unitOfWork.Commit();
                         }
                     }


                     response = request.CreateResponse(HttpStatusCode.OK, new { success = true });




                 }

                 return response;
             });
         }




         [HttpPost]
         [Route("update")]
         public HttpResponseMessage Update(HttpRequestMessage request, CategoryViewModel categoryItem)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     var categorytemDb = _categoriesRepository.GetSingle(categoryItem.ID);
                     if (categorytemDb == null)
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid categoryItem.");
                     else
                     {
                         categorytemDb.UpdateCategoryItemEdit(categoryItem);
                         _categoriesRepository.Edit(categorytemDb);

                         _unitOfWork.Commit();
                         response = request.CreateResponse<CategoryViewModel>(HttpStatusCode.OK, categoryItem);
                     }
                 }

                 return response;
             });
         }

     }


}
