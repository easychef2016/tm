﻿using AutoMapper;
using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EasyChefDemo.Web.Infrastructure.Extensions;
using EasyChefDemo.Web.Infrastructure.Filters;
using EasyChefDemo.Web.Infrastructure.Filters;

namespace EasyChefDemo.Web.Controllers
{

      [DeflateCompression]
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/recipies")]
    public class RecipiesController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Recipe> _recipiesRepository;
        private readonly IEntityBaseRepository<RecipeIngredient> _recipeIngredientsRepository;
        private readonly IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
        public RecipiesController(IEntityBaseRepository<Recipe> recipiesRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork,
            
            IEntityBaseRepository<RecipeIngredient> recipeIngredientsRepository,
            IEntityBaseRepository<InventoryItem> inventoryItemsRepository
            
            )
            : base(_errorsRepository, _unitOfWork)
        {
            _recipiesRepository = recipiesRepository;
            _recipeIngredientsRepository = recipeIngredientsRepository;
            _inventoryItemsRepository = inventoryItemsRepository;

        }

        [AllowAnonymous]
        [Route("latest")]
        public HttpResponseMessage Get(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                //var recipies = _recipiesRepository.GetAll().OrderByDescending(r => r.CreatedDate).Take(6).ToList();

                var recipies = _recipiesRepository.AllIncluding(ri => ri.RecipeIngredients).ToList();
                IEnumerable<RecipiesViewModel> recipiesVM = Mapper.Map<IEnumerable<Recipe>, IEnumerable<RecipiesViewModel>>(recipies);
                response = request.CreateResponse<IEnumerable<RecipiesViewModel> >(HttpStatusCode.OK, recipiesVM);


                //var recipies = _recipeIngredientsRepository.AllIncluding(ri => ri.InventoryItem, ri => ri.Recipe).ToList();

                //IEnumerable<RecipeIngredientViewModel> recipiesVM = Mapper.Map<IEnumerable<RecipeIngredient>, IEnumerable<RecipeIngredientViewModel>>(recipies);
                //response = request.CreateResponse<IEnumerable<RecipeIngredientViewModel>>(HttpStatusCode.OK, recipiesVM);

               


                return response;
            });
        }

        //[Route("details/{id:int}")]
        //public HttpResponseMessage Get(HttpRequestMessage request, int id)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        var movie = _moviesRepository.GetSingle(id);

        //        MovieViewModel movieVM = Mapper.Map<Movie, MovieViewModel>(movie);

        //        response = request.CreateResponse<MovieViewModel>(HttpStatusCode.OK, movieVM);

        //        return response;
        //    });
        //}

        //[AllowAnonymous]
        //[Route("{page:int=0}/{pageSize=3}/{filter?}")]
        //public HttpResponseMessage Get(HttpRequestMessage request, int? page, int? pageSize, string filter = null)
        //{
        //    int currentPage = page.Value;
        //    int currentPageSize = pageSize.Value;

        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        List<Movie> movies = null;
        //        int totalMovies = new int();

        //        if (!string.IsNullOrEmpty(filter))
        //        {
        //            movies = _moviesRepository
        //                .FindBy(m => m.Title.ToLower()
        //                .Contains(filter.ToLower().Trim()))
        //                .OrderBy(m => m.ID)
        //                .Skip(currentPage * currentPageSize)
        //                .Take(currentPageSize)
        //                .ToList();

        //            totalMovies = _moviesRepository
        //                .FindBy(m => m.Title.ToLower()
        //                .Contains(filter.ToLower().Trim()))
        //                .Count();
        //        }
        //        else
        //        {
        //            movies = _moviesRepository
        //                .GetAll()
        //                .OrderBy(m => m.ID)
        //                .Skip(currentPage * currentPageSize)
        //                .Take(currentPageSize)
        //                .ToList();

        //            totalMovies = _moviesRepository.GetAll().Count();
        //        }

        //        IEnumerable<MovieViewModel> moviesVM = Mapper.Map<IEnumerable<Movie>, IEnumerable<MovieViewModel>>(movies);

        //        PaginationSet<MovieViewModel> pagedSet = new PaginationSet<MovieViewModel>()
        //        {
        //            Page = currentPage,
        //            TotalCount = totalMovies,
        //            TotalPages = (int)Math.Ceiling((decimal)totalMovies / currentPageSize),
        //            Items = moviesVM
        //        };

        //        response = request.CreateResponse<PaginationSet<MovieViewModel>>(HttpStatusCode.OK, pagedSet);

        //        return response;
        //    });
        //}

        [HttpPost]
        [Route("add")]
        public HttpResponseMessage Add(HttpRequestMessage request, RecipiesViewModel recipe)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    Recipe newRecipe = new Recipe();
                    newRecipe.UpdateRecipe(recipe);

                    //for (int i = 0; i < recipe.NumberOfStocks; i++)
                    //{
                    //    Stock stock = new Stock()
                    //    {
                    //        IsAvailable = true,
                    //        Movie = newMovie,
                    //        UniqueKey = Guid.NewGuid()
                    //    };
                    //    newMovie.Stocks.Add(stock);
                    //}

                    //_moviesRepository.Add(newMovie);

                    //_unitOfWork.Commit();

                    //// Update view model
                    //movie = Mapper.Map<Movie, MovieViewModel>(newMovie);
                    //response = request.CreateResponse<MovieViewModel>(HttpStatusCode.Created, movie);
                }

                return response;
            });
        }

        //[HttpPost]
        //[Route("update")]
        //public HttpResponseMessage Update(HttpRequestMessage request, MovieViewModel movie)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;

        //        if (!ModelState.IsValid)
        //        {
        //            response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //        }
        //        else
        //        {
        //            var movieDb = _moviesRepository.GetSingle(movie.ID);
        //            if (movieDb == null)
        //                response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid movie.");
        //            else
        //            {
        //                movieDb.UpdateMovie(movie);
        //                movie.Image = movieDb.Image;
        //                _moviesRepository.Edit(movieDb);

        //                _unitOfWork.Commit();
        //                response = request.CreateResponse<MovieViewModel>(HttpStatusCode.OK, movie);
        //            }
        //        }

        //        return response;
        //    });
        //}

        //[MimeMultipart]
        //[Route("images/upload")]
        //public HttpResponseMessage Post(HttpRequestMessage request, int movieId)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;

        //        var movieOld = _moviesRepository.GetSingle(movieId);
        //        if (movieOld == null)
        //            response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid movie.");
        //        else
        //        {
        //            var uploadPath = HttpContext.Current.Server.MapPath("~/Content/images/movies");

        //            var multipartFormDataStreamProvider = new UploadMultipartFormProvider(uploadPath);

        //            // Read the MIME multipart asynchronously 
        //            Request.Content.ReadAsMultipartAsync(multipartFormDataStreamProvider);

        //            string _localFileName = multipartFormDataStreamProvider
        //                .FileData.Select(multiPartData => multiPartData.LocalFileName).FirstOrDefault();

        //            // Create response
        //            FileUploadResult fileUploadResult = new FileUploadResult
        //            {
        //                LocalFilePath = _localFileName,

        //                FileName = Path.GetFileName(_localFileName),

        //                FileLength = new FileInfo(_localFileName).Length
        //            };

        //            // update database
        //            movieOld.Image = fileUploadResult.FileName;
        //            _moviesRepository.Edit(movieOld);
        //            _unitOfWork.Commit();

        //            response = request.CreateResponse(HttpStatusCode.OK, fileUploadResult);
        //        }

        //        return response;
        //    });
        //}
    }



      [Authorize(Roles = "Admin")]
      [RoutePrefix("mobileapi/recipies")]
      public class MobileRecipiesController : ApiControllerBase
      {
          private readonly IEntityBaseRepository<Recipe> _recipiesRepository;
          private readonly IEntityBaseRepository<RecipeIngredient> _recipeIngredientsRepository;
          private readonly IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
          public MobileRecipiesController(IEntityBaseRepository<Recipe> recipiesRepository,
              IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork,

              IEntityBaseRepository<RecipeIngredient> recipeIngredientsRepository,
              IEntityBaseRepository<InventoryItem> inventoryItemsRepository

              )
              : base(_errorsRepository, _unitOfWork)
          {
              _recipiesRepository = recipiesRepository;
              _recipeIngredientsRepository = recipeIngredientsRepository;
              _inventoryItemsRepository = inventoryItemsRepository;

          }

          [AllowAnonymous]
          [Route("latest")]
          public HttpResponseMessage Get(HttpRequestMessage request)
          {
              return CreateHttpResponse(request, () =>
              {
                  HttpResponseMessage response = null;

                  //var recipies = _recipiesRepository.GetAll().OrderByDescending(r => r.CreatedDate).Take(6).ToList();

                  var recipies = _recipiesRepository.AllIncluding(ri => ri.RecipeIngredients).ToList();
                  IEnumerable<RecipiesViewModel> recipiesVM = Mapper.Map<IEnumerable<Recipe>, IEnumerable<RecipiesViewModel>>(recipies);
                  response = request.CreateResponse<IEnumerable<RecipiesViewModel>>(HttpStatusCode.OK, recipiesVM);


                  //var recipies = _recipeIngredientsRepository.AllIncluding(ri => ri.InventoryItem, ri => ri.Recipe).ToList();

                  //IEnumerable<RecipeIngredientViewModel> recipiesVM = Mapper.Map<IEnumerable<RecipeIngredient>, IEnumerable<RecipeIngredientViewModel>>(recipies);
                  //response = request.CreateResponse<IEnumerable<RecipeIngredientViewModel>>(HttpStatusCode.OK, recipiesVM);




                  return response;
              });
          }

          //[Route("details/{id:int}")]
          //public HttpResponseMessage Get(HttpRequestMessage request, int id)
          //{
          //    return CreateHttpResponse(request, () =>
          //    {
          //        HttpResponseMessage response = null;
          //        var movie = _moviesRepository.GetSingle(id);

          //        MovieViewModel movieVM = Mapper.Map<Movie, MovieViewModel>(movie);

          //        response = request.CreateResponse<MovieViewModel>(HttpStatusCode.OK, movieVM);

          //        return response;
          //    });
          //}

          //[AllowAnonymous]
          //[Route("{page:int=0}/{pageSize=3}/{filter?}")]
          //public HttpResponseMessage Get(HttpRequestMessage request, int? page, int? pageSize, string filter = null)
          //{
          //    int currentPage = page.Value;
          //    int currentPageSize = pageSize.Value;

          //    return CreateHttpResponse(request, () =>
          //    {
          //        HttpResponseMessage response = null;
          //        List<Movie> movies = null;
          //        int totalMovies = new int();

          //        if (!string.IsNullOrEmpty(filter))
          //        {
          //            movies = _moviesRepository
          //                .FindBy(m => m.Title.ToLower()
          //                .Contains(filter.ToLower().Trim()))
          //                .OrderBy(m => m.ID)
          //                .Skip(currentPage * currentPageSize)
          //                .Take(currentPageSize)
          //                .ToList();

          //            totalMovies = _moviesRepository
          //                .FindBy(m => m.Title.ToLower()
          //                .Contains(filter.ToLower().Trim()))
          //                .Count();
          //        }
          //        else
          //        {
          //            movies = _moviesRepository
          //                .GetAll()
          //                .OrderBy(m => m.ID)
          //                .Skip(currentPage * currentPageSize)
          //                .Take(currentPageSize)
          //                .ToList();

          //            totalMovies = _moviesRepository.GetAll().Count();
          //        }

          //        IEnumerable<MovieViewModel> moviesVM = Mapper.Map<IEnumerable<Movie>, IEnumerable<MovieViewModel>>(movies);

          //        PaginationSet<MovieViewModel> pagedSet = new PaginationSet<MovieViewModel>()
          //        {
          //            Page = currentPage,
          //            TotalCount = totalMovies,
          //            TotalPages = (int)Math.Ceiling((decimal)totalMovies / currentPageSize),
          //            Items = moviesVM
          //        };

          //        response = request.CreateResponse<PaginationSet<MovieViewModel>>(HttpStatusCode.OK, pagedSet);

          //        return response;
          //    });
          //}


           [AllowAnonymous]
          [HttpPost]
          [Route("add")]
          public HttpResponseMessage Add(HttpRequestMessage request, RecipiesViewModel recipe)
          {
              return CreateHttpResponse(request, () =>
              {
                  HttpResponseMessage response = null;

                  if (!ModelState.IsValid)
                  {
                      response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                  }
                  else
                  {
                      Recipe newRecipe = new Recipe();
                      newRecipe.UpdateRecipe(recipe);

                      //for (int i = 0; i < recipe.NumberOfStocks; i++)
                      //{
                      //    Stock stock = new Stock()
                      //    {
                      //        IsAvailable = true,
                      //        Movie = newMovie,
                      //        UniqueKey = Guid.NewGuid()
                      //    };
                      //    newMovie.Stocks.Add(stock);
                      //}

                      //_moviesRepository.Add(newMovie);

                      //_unitOfWork.Commit();

                      //// Update view model
                      //movie = Mapper.Map<Movie, MovieViewModel>(newMovie);
                      //response = request.CreateResponse<MovieViewModel>(HttpStatusCode.Created, movie);
                  }

                  return response;
              });
          }

          //[HttpPost]
          //[Route("update")]
          //public HttpResponseMessage Update(HttpRequestMessage request, MovieViewModel movie)
          //{
          //    return CreateHttpResponse(request, () =>
          //    {
          //        HttpResponseMessage response = null;

          //        if (!ModelState.IsValid)
          //        {
          //            response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
          //        }
          //        else
          //        {
          //            var movieDb = _moviesRepository.GetSingle(movie.ID);
          //            if (movieDb == null)
          //                response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid movie.");
          //            else
          //            {
          //                movieDb.UpdateMovie(movie);
          //                movie.Image = movieDb.Image;
          //                _moviesRepository.Edit(movieDb);

          //                _unitOfWork.Commit();
          //                response = request.CreateResponse<MovieViewModel>(HttpStatusCode.OK, movie);
          //            }
          //        }

          //        return response;
          //    });
          //}

          //[MimeMultipart]
          //[Route("images/upload")]
          //public HttpResponseMessage Post(HttpRequestMessage request, int movieId)
          //{
          //    return CreateHttpResponse(request, () =>
          //    {
          //        HttpResponseMessage response = null;

          //        var movieOld = _moviesRepository.GetSingle(movieId);
          //        if (movieOld == null)
          //            response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid movie.");
          //        else
          //        {
          //            var uploadPath = HttpContext.Current.Server.MapPath("~/Content/images/movies");

          //            var multipartFormDataStreamProvider = new UploadMultipartFormProvider(uploadPath);

          //            // Read the MIME multipart asynchronously 
          //            Request.Content.ReadAsMultipartAsync(multipartFormDataStreamProvider);

          //            string _localFileName = multipartFormDataStreamProvider
          //                .FileData.Select(multiPartData => multiPartData.LocalFileName).FirstOrDefault();

          //            // Create response
          //            FileUploadResult fileUploadResult = new FileUploadResult
          //            {
          //                LocalFilePath = _localFileName,

          //                FileName = Path.GetFileName(_localFileName),

          //                FileLength = new FileInfo(_localFileName).Length
          //            };

          //            // update database
          //            movieOld.Image = fileUploadResult.FileName;
          //            _moviesRepository.Edit(movieOld);
          //            _unitOfWork.Commit();

          //            response = request.CreateResponse(HttpStatusCode.OK, fileUploadResult);
          //        }

          //        return response;
          //    });
          //}
      }

}
