﻿using AutoMapper;
using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EasyChefDemo.Web.Infrastructure.Extensions;
using EasyChefDemo.Web.Infrastructure.Filters;
using System.Net.Http.Headers;

namespace EasyChefDemo.Web.Controllers
{

     [DeflateCompression]
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/inventoryitems")]
    public class InventoryItemsController : ApiControllerBase
    {

        private readonly IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
        public InventoryItemsController(IEntityBaseRepository<InventoryItem> inventoryItemsRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork


            )
            : base(_errorsRepository, _unitOfWork)
        {

            _inventoryItemsRepository = inventoryItemsRepository;

        }

        //[AllowAnonymous]
        //[Route("latest")]
        //public HttpResponseMessage Get(HttpRequestMessage request)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;

        //        //var recipies = _recipiesRepository.GetAll().OrderByDescending(r => r.CreatedDate).Take(6).ToList();

        //        var recipies = _recipiesRepository.AllIncluding(ri => ri.RecipeIngredients).ToList();
        //        IEnumerable<RecipiesViewModel> recipiesVM = Mapper.Map<IEnumerable<Recipe>, IEnumerable<RecipiesViewModel>>(recipies);
        //        response = request.CreateResponse<IEnumerable<RecipiesViewModel>>(HttpStatusCode.OK, recipiesVM);


        //        //var recipies = _recipeIngredientsRepository.AllIncluding(ri => ri.InventoryItem, ri => ri.Recipe).ToList();

        //        //IEnumerable<RecipeIngredientViewModel> recipiesVM = Mapper.Map<IEnumerable<RecipeIngredient>, IEnumerable<RecipeIngredientViewModel>>(recipies);
        //        //response = request.CreateResponse<IEnumerable<RecipeIngredientViewModel>>(HttpStatusCode.OK, recipiesVM);




        //        return response;
        //    });
        //}

        [Route("details/{id:int}")]
        [CacheFilter(TimeDuration = 100)]  
        public HttpResponseMessage Get(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var inventoryItem = _inventoryItemsRepository.GetSingle(id);

                InventoryItemViewModel inventoryItemVM = Mapper.Map<InventoryItem, InventoryItemViewModel>(inventoryItem);

                response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItemVM);
                response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                return response;
            });
        }

        public HttpResponseMessage Get(HttpRequestMessage request, string filter)
        {
            filter = filter.ToLower().Trim();

            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var inventoryItems = _inventoryItemsRepository.GetAll()
                    .Where(it => it.Name.ToLower().Contains(filter) ||
                    it.ItemDescription.ToLower().Contains(filter)).ToList();

                var inventoryItemsVM = Mapper.Map<IEnumerable<InventoryItem>, IEnumerable<InventoryItemViewModel>>(inventoryItems);
                response = request.CreateResponse<IEnumerable<InventoryItemViewModel>>(HttpStatusCode.OK, inventoryItemsVM);
                response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                return response;


            });
        }

        [AllowAnonymous]
        [Route("search/{page:int=0}/{pageSize=4}/{filter?}")]
        public HttpResponseMessage Search(HttpRequestMessage request, int? page, int? pageSize, string filter = null)
        {
            int currentPage = page.Value;
            int currentPageSize = pageSize.Value;

            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                List<InventoryItem> inventoryItems = null;
                int totalInventoryItems = new int();

                if (!string.IsNullOrEmpty(filter))
                {
                    inventoryItems = _inventoryItemsRepository
                        .FindBy(it => it.Name.ToLower()
                        .Contains(filter.ToLower().Trim()))
                        .OrderBy(it => it.ID)
                        .Skip(currentPage * currentPageSize)
                        .Take(currentPageSize)
                        .ToList();

                    totalInventoryItems = _inventoryItemsRepository
                        .FindBy(it => it.Name.ToLower()
                        .Contains(filter.ToLower().Trim()))
                        .Count();
                }
                else
                {
                    inventoryItems = _inventoryItemsRepository
                        .GetAll()
                        .OrderBy(it => it.ID)
                        .Skip(currentPage * currentPageSize)
                        .Take(currentPageSize)
                        .ToList();

                    totalInventoryItems = _inventoryItemsRepository.GetAll().Count();
                }

                IEnumerable<InventoryItemViewModel> inventoryItemsVM = Mapper.Map<IEnumerable<InventoryItem>, IEnumerable<InventoryItemViewModel>>(inventoryItems);

                PaginationSet<InventoryItemViewModel> pagedSet = new PaginationSet<InventoryItemViewModel>()
                {
                    Page = currentPage,
                    TotalCount = totalInventoryItems,
                    TotalPages = (int)Math.Ceiling((decimal)totalInventoryItems / currentPageSize),
                    Items = inventoryItemsVM
                };

                response = request.CreateResponse<PaginationSet<InventoryItemViewModel>>(HttpStatusCode.OK, pagedSet);

                return response;
            });
        }


        [AllowAnonymous]
        [Route("latest")]
        [CacheFilter(TimeDuration = 100)]  
        public HttpResponseMessage Get(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;



                var inventoryItems = _inventoryItemsRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();

                IEnumerable<InventoryItemViewModel> inventoryItemVM = Mapper.Map<IEnumerable<InventoryItem>, IEnumerable<InventoryItemViewModel>>(inventoryItems);
                response = request.CreateResponse<IEnumerable<InventoryItemViewModel>>(HttpStatusCode.OK, inventoryItemVM);


                //var recipies = _recipeIngredientsRepository.AllIncluding(ri => ri.InventoryItem, ri => ri.Recipe).ToList();

                //IEnumerable<RecipeIngredientViewModel> recipiesVM = Mapper.Map<IEnumerable<RecipeIngredient>, IEnumerable<RecipeIngredientViewModel>>(recipies);
                //response = request.CreateResponse<IEnumerable<RecipeIngredientViewModel>>(HttpStatusCode.OK, recipiesVM);




                return response;
            });
        }


        [HttpPost]
        [Route("add")]
        public HttpResponseMessage Add(HttpRequestMessage request, List<InventoryItem> inventoryitems)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    InventoryItem newinventoryItem = new InventoryItem();
                    if (inventoryitems != null)
                    {
                        foreach (var inventoryitem in inventoryitems)
                        {
                            newinventoryItem.UpdateInventoryItem(inventoryitem);
                            _inventoryItemsRepository.Add(newinventoryItem);
                            _unitOfWork.Commit();
                        }
                    }

                    response = request.CreateResponse(HttpStatusCode.OK, new { success = true });

                }

                return response;
            });
        }

        [HttpPost]
        [Route("update")]
        public HttpResponseMessage Update(HttpRequestMessage request, InventoryItemViewModel inventoryItem)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    var inventoryItemDb = _inventoryItemsRepository.GetSingle(inventoryItem.ID);
                    if (inventoryItemDb == null)
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                    else
                    {
                        inventoryItemDb.UpdateInventoryItemEdit(inventoryItem);
                        //movie.Image = movieDb.Image;
                        _inventoryItemsRepository.Edit(inventoryItemDb);

                        _unitOfWork.Commit();
                        response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItem);
                    }
                }

                return response;
            });
        }


        [HttpPost]
        [Route("delete")]
        public HttpResponseMessage Delete(HttpRequestMessage request, InventoryItemViewModel inventoryItem)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                
                var inventoryItemDb = _inventoryItemsRepository.GetSingle(inventoryItem.ID);
                if (inventoryItemDb == null)
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                else
                {

                    if (inventoryItemDb.Name.ToLower().ToString() == inventoryItem.Name.ToLower().ToString())
                    {
                        _inventoryItemsRepository.Delete(inventoryItemDb);
                        _unitOfWork.Commit();
                        response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItem);

                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                    
                    }
                    
                }


                return response;
            });
        }

        //[MimeMultipart]
        //[Route("images/upload")]
        //public HttpResponseMessage Post(HttpRequestMessage request, int movieId)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;

        //        var movieOld = _moviesRepository.GetSingle(movieId);
        //        if (movieOld == null)
        //            response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid movie.");
        //        else
        //        {
        //            var uploadPath = HttpContext.Current.Server.MapPath("~/Content/images/movies");

        //            var multipartFormDataStreamProvider = new UploadMultipartFormProvider(uploadPath);

        //            // Read the MIME multipart asynchronously 
        //            Request.Content.ReadAsMultipartAsync(multipartFormDataStreamProvider);

        //            string _localFileName = multipartFormDataStreamProvider
        //                .FileData.Select(multiPartData => multiPartData.LocalFileName).FirstOrDefault();

        //            // Create response
        //            FileUploadResult fileUploadResult = new FileUploadResult
        //            {
        //                LocalFilePath = _localFileName,

        //                FileName = Path.GetFileName(_localFileName),

        //                FileLength = new FileInfo(_localFileName).Length
        //            };

        //            // update database
        //            movieOld.Image = fileUploadResult.FileName;
        //            _moviesRepository.Edit(movieOld);
        //            _unitOfWork.Commit();

        //            response = request.CreateResponse(HttpStatusCode.OK, fileUploadResult);
        //        }

        //        return response;
        //    });
        //}
    }


     [Authorize(Roles = "Admin")]
     [RoutePrefix("mobileapi/inventoryitems")]
     public class MobileInventoryItemsController : ApiControllerBase
     {

         private readonly IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
         public MobileInventoryItemsController(IEntityBaseRepository<InventoryItem> inventoryItemsRepository,
             IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork


             )
             : base(_errorsRepository, _unitOfWork)
         {

             _inventoryItemsRepository = inventoryItemsRepository;

         }

         //[AllowAnonymous]
         //[Route("latest")]
         //public HttpResponseMessage Get(HttpRequestMessage request)
         //{
         //    return CreateHttpResponse(request, () =>
         //    {
         //        HttpResponseMessage response = null;

         //        //var recipies = _recipiesRepository.GetAll().OrderByDescending(r => r.CreatedDate).Take(6).ToList();

         //        var recipies = _recipiesRepository.AllIncluding(ri => ri.RecipeIngredients).ToList();
         //        IEnumerable<RecipiesViewModel> recipiesVM = Mapper.Map<IEnumerable<Recipe>, IEnumerable<RecipiesViewModel>>(recipies);
         //        response = request.CreateResponse<IEnumerable<RecipiesViewModel>>(HttpStatusCode.OK, recipiesVM);


         //        //var recipies = _recipeIngredientsRepository.AllIncluding(ri => ri.InventoryItem, ri => ri.Recipe).ToList();

         //        //IEnumerable<RecipeIngredientViewModel> recipiesVM = Mapper.Map<IEnumerable<RecipeIngredient>, IEnumerable<RecipeIngredientViewModel>>(recipies);
         //        //response = request.CreateResponse<IEnumerable<RecipeIngredientViewModel>>(HttpStatusCode.OK, recipiesVM);




         //        return response;
         //    });
         //}

         [Route("details/{id:int}")]
         [CacheFilter(TimeDuration = 100)]
         public HttpResponseMessage Get(HttpRequestMessage request, int id)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 var inventoryItem = _inventoryItemsRepository.GetSingle(id);

                 InventoryItemViewModel inventoryItemVM = Mapper.Map<InventoryItem, InventoryItemViewModel>(inventoryItem);

                 response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItemVM);

                 return response;
             });
         }

         public HttpResponseMessage Get(HttpRequestMessage request, string filter)
         {
             filter = filter.ToLower().Trim();

             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var inventoryItems = _inventoryItemsRepository.GetAll()
                     .Where(it => it.Name.ToLower().Contains(filter) ||
                     it.ItemDescription.ToLower().Contains(filter)).ToList();

                 var inventoryItemsVM = Mapper.Map<IEnumerable<InventoryItem>, IEnumerable<InventoryItemViewModel>>(inventoryItems);
                 response = request.CreateResponse<IEnumerable<InventoryItemViewModel>>(HttpStatusCode.OK, inventoryItemsVM);
                 return response;


             });
         }

         [AllowAnonymous]
         [Route("search/{page:int=0}/{pageSize=4}/{filter?}")]
         public HttpResponseMessage Search(HttpRequestMessage request, int? page, int? pageSize, string filter = null)
         {
             int currentPage = page.Value;
             int currentPageSize = pageSize.Value;

             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 List<InventoryItem> inventoryItems = null;
                 int totalInventoryItems = new int();

                 if (!string.IsNullOrEmpty(filter))
                 {
                     inventoryItems = _inventoryItemsRepository
                         .FindBy(it => it.Name.ToLower()
                         .Contains(filter.ToLower().Trim()))
                         .OrderBy(it => it.ID)
                         .Skip(currentPage * currentPageSize)
                         .Take(currentPageSize)
                         .ToList();

                     totalInventoryItems = _inventoryItemsRepository
                         .FindBy(it => it.Name.ToLower()
                         .Contains(filter.ToLower().Trim()))
                         .Count();
                 }
                 else
                 {
                     inventoryItems = _inventoryItemsRepository
                         .GetAll()
                         .OrderBy(it => it.ID)
                         .Skip(currentPage * currentPageSize)
                         .Take(currentPageSize)
                         .ToList();

                     totalInventoryItems = _inventoryItemsRepository.GetAll().Count();
                 }

                 IEnumerable<InventoryItemViewModel> inventoryItemsVM = Mapper.Map<IEnumerable<InventoryItem>, IEnumerable<InventoryItemViewModel>>(inventoryItems);

                 PaginationSet<InventoryItemViewModel> pagedSet = new PaginationSet<InventoryItemViewModel>()
                 {
                     Page = currentPage,
                     TotalCount = totalInventoryItems,
                     TotalPages = (int)Math.Ceiling((decimal)totalInventoryItems / currentPageSize),
                     Items = inventoryItemsVM
                 };

                 response = request.CreateResponse<PaginationSet<InventoryItemViewModel>>(HttpStatusCode.OK, pagedSet);

                 return response;
             });
         }


         [AllowAnonymous]
         [Route("latest")]
         [CacheFilter(TimeDuration = 100)]
         public HttpResponseMessage Get(HttpRequestMessage request)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;



                 var inventoryItems = _inventoryItemsRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();

                 IEnumerable<InventoryItemViewModel> inventoryItemVM = Mapper.Map<IEnumerable<InventoryItem>, IEnumerable<InventoryItemViewModel>>(inventoryItems);
                 response = request.CreateResponse<IEnumerable<InventoryItemViewModel>>(HttpStatusCode.OK, inventoryItemVM);


                 //var recipies = _recipeIngredientsRepository.AllIncluding(ri => ri.InventoryItem, ri => ri.Recipe).ToList();

                 //IEnumerable<RecipeIngredientViewModel> recipiesVM = Mapper.Map<IEnumerable<RecipeIngredient>, IEnumerable<RecipeIngredientViewModel>>(recipies);
                 //response = request.CreateResponse<IEnumerable<RecipeIngredientViewModel>>(HttpStatusCode.OK, recipiesVM);




                 return response;
             });
         }


         [HttpPost]
         [Route("add")]
         public HttpResponseMessage Add(HttpRequestMessage request, List<InventoryItem> inventoryitems)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     InventoryItem newinventoryItem = new InventoryItem();
                     if (inventoryitems != null)
                     {
                         foreach (var inventoryitem in inventoryitems)
                         {
                             newinventoryItem.UpdateInventoryItem(inventoryitem);
                             _inventoryItemsRepository.Add(newinventoryItem);
                             _unitOfWork.Commit();
                         }
                     }

                     response = request.CreateResponse(HttpStatusCode.OK, new { success = true });

                 }

                 return response;
             });
         }

         [HttpPost]
         [Route("update")]
         public HttpResponseMessage Update(HttpRequestMessage request, InventoryItemViewModel inventoryItem)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     var inventoryItemDb = _inventoryItemsRepository.GetSingle(inventoryItem.ID);
                     if (inventoryItemDb == null)
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                     else
                     {
                         inventoryItemDb.UpdateInventoryItemEdit(inventoryItem);
                         //movie.Image = movieDb.Image;
                         _inventoryItemsRepository.Edit(inventoryItemDb);

                         _unitOfWork.Commit();
                         response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItem);
                     }
                 }

                 return response;
             });
         }


         [HttpPost]
         [Route("delete")]
         public HttpResponseMessage Delete(HttpRequestMessage request, InventoryItemViewModel inventoryItem)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var inventoryItemDb = _inventoryItemsRepository.GetSingle(inventoryItem.ID);
                 if (inventoryItemDb == null)
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                 else
                 {

                     if (inventoryItemDb.Name.ToLower().ToString() == inventoryItem.Name.ToLower().ToString())
                     {
                         _inventoryItemsRepository.Delete(inventoryItemDb);
                         _unitOfWork.Commit();
                         response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItem);

                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");

                     }

                 }


                 return response;
             });
         }

         //[MimeMultipart]
         //[Route("images/upload")]
         //public HttpResponseMessage Post(HttpRequestMessage request, int movieId)
         //{
         //    return CreateHttpResponse(request, () =>
         //    {
         //        HttpResponseMessage response = null;

         //        var movieOld = _moviesRepository.GetSingle(movieId);
         //        if (movieOld == null)
         //            response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid movie.");
         //        else
         //        {
         //            var uploadPath = HttpContext.Current.Server.MapPath("~/Content/images/movies");

         //            var multipartFormDataStreamProvider = new UploadMultipartFormProvider(uploadPath);

         //            // Read the MIME multipart asynchronously 
         //            Request.Content.ReadAsMultipartAsync(multipartFormDataStreamProvider);

         //            string _localFileName = multipartFormDataStreamProvider
         //                .FileData.Select(multiPartData => multiPartData.LocalFileName).FirstOrDefault();

         //            // Create response
         //            FileUploadResult fileUploadResult = new FileUploadResult
         //            {
         //                LocalFilePath = _localFileName,

         //                FileName = Path.GetFileName(_localFileName),

         //                FileLength = new FileInfo(_localFileName).Length
         //            };

         //            // update database
         //            movieOld.Image = fileUploadResult.FileName;
         //            _moviesRepository.Edit(movieOld);
         //            _unitOfWork.Commit();

         //            response = request.CreateResponse(HttpStatusCode.OK, fileUploadResult);
         //        }

         //        return response;
         //    });
         //}
     }
}
