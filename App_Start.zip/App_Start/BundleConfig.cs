﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Optimization;


namespace EasyChefDemo.Web.App_Start
{

    public class BundleConfig
    {

        public static void RegisterBundles(BundleCollection bundles)
        {
            //   bundles.Clear();
            //   bundles.ResetAll();
            RegisterScripts(bundles);
            RegisterStyles(bundles);


            BundleTable.EnableOptimizations = false;
        }
        public static void RegisterScripts(BundleCollection bundles)
        {


            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                       "~/Scripts/Vendors/jquery-3.1.1.js",
                        "~/Scripts/Vendors/jquery-ui-1.11.4.min.js"

                       ));


            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/Scripts/Vendors/modernizr.js"));

            bundles.Add(new ScriptBundle("~/bundles/vendorsripts").Include(

                //----- Bootstrap -----------------------------------------------------
                "~/Scripts/Vendors/bootstrap.min.js",
                "~/Scripts/Vendors/bootstrap-select/js/bootstrap-select.min.js",

                 "~/Scripts/Vendors/angular.min.js",
                 "~/Scripts/Vendors/angular-animate.js",
                 "~/Scripts/Vendors/angular-sanitize.js",
                // Project related files
                "~/Scripts/Vendors/angular-ui-router.min.js",
                 "~/Scripts/Vendors/angular-resource.js",
                  //--- Added for Data table
                  "~/Scripts/Vendors/ui-bootstrap-tpls.min.js",
                  //--- Added for Data table
                  "~/Scripts/Vendors/angular-ui-utils.min.js",
                  "~/Scripts/Vendors/jquery.dataTables.min.js",
                  "~/Scripts/Vendors/dataTables.bootstrap.min.js",
                   "~/Scripts/Vendors/jquery.fancybox.js",
                   "~/Scripts/Vendors/jquery.fancybox-media.js",

                   // "~/Scripts/spa/layout/AdminBSB.js",



                   //----------------------BSB  STYLE -------------------
                   "~/Scripts/Vendors/jquery.slimscroll.min.js",

                "~/Scripts/Vendors/waves.min.js",

                //  "~/content/css/Vendors/jquery.slimscroll.min.js",
                // "~/content/css/MPMaterial/node-waves/waves.min.js",
                //----------------------BSB  STYLE -------------------
                //   "~/content/css/AdminLTE/JS/material.js",
                //     "~/content/css/AdminLTE/JS/ripples.min.js",
                //   "~/content/css/AdminLTE/JS/AdminLTE.js",
                "~/Scripts/Vendors/underscore.js",
                "~/Scripts/Vendors/raphael.js",
                "~/Scripts/Vendors/morris.js",

                //----- Angular -----------------------------------------------------
                "~/Scripts/Vendors/angular-cookies.js",
                "~/Scripts/Vendors/angular-validator.js",
                "~/Scripts/Vendors/angular-base64.js",
                "~/Scripts/Vendors/angular-file-upload.js",
                "~/Scripts/Vendors/angucomplete-alt.min.js",
                "~/Scripts/Vendors/angular-toggle-switch.js",
                "~/Scripts/Vendors/angular-ui-switch.js",
                "~/Scripts/Vendors/smart-table.js",
                 //Added for Material 
                 "~/Scripts/Vendors/angular-material.js",
                "~/Scripts/Vendors/angular-aria.js",
                "~/Scripts/Vendors/angular-messages.js",
                 //-------------------------------------------------------End Material 

                 "~/Scripts/Vendors/ngPrint.js",
                   //  "~/Scripts/spa/vendor/place-autocomplete.js",
                   //"~/Scripts/spa/components/ngAutocomplete.js",
                   //"~/Scripts/spa/components/myGoogleplaces.js",
                   "~/Scripts/Vendors/angular-material-icons.js",
                 "~/Scripts/Vendors/md-data-table.js",
                  "~/Scripts/Vendors/md-data-table-templates.js",
                  "~/Scripts/Vendors/ms-form-wizard.directive.js",
                  //Added on 09/08/2016  for MD stepper wizard
                  "~/Scripts/spa/components/md-steppers.js",
                  //Added for Unique
                  "~/Scripts/spa/components/angular-ui.min.js",
                  //Added for page smooth scroll
                  "~/Scripts/spa/components/angular-smoothscroll.js",
                  "~/Scripts/Vendors/tether.min.js",
                  "~/Scripts/Vendors/toastr.js",
                  "~/Scripts/Vendors/jquery.raty.js",
                  "~/Scripts/Vendors/respond.src.js",
                  "~/Scripts/Vendors/ui-bootstrap.js",
                  "~/Scripts/Vendors/wow.min.js",


                  "~/Scripts/Vendors/loading-bar.js",
                     "~/content/css/managepad/bootstrap-datepicker.min.js"

                ));

            bundles.Add(new ScriptBundle("~/bundles/allspa").Include(

                //   "~/Scripts/spa/components/Datepicker.js",
                //  "~/Scripts/spa/components/datepicker.directive.js",
                //   "~/Scripts/spa/components/datepickerCtrl.js",
                "~/Scripts/spa/modules/common.core.js",
                "~/Scripts/spa/modules/common.ui.js",
                "~/Scripts/spa/app.js",
                "~/Scripts/spa/services/apiService.js",
                "~/Scripts/spa/services/notificationService.js",
                "~/Scripts/spa/services/membershipService.js",
                "~/Scripts/spa/services/fileUploadService.js",

                //Directives
                "~/Scripts/spa/components/myDatepicker.js",
                "~/Scripts/spa/components/ngGooglePlaces.js",
                "~/Scripts/spa/components/ngMask.js",
                "~/Scripts/spa/home/rootCtrl.js",
                "~/Scripts/spa/account/loginCtrl.js",
                //Dashboard
                "~/Scripts/spa/Dashboard/dashboardCtrl.js",
                "~/Scripts/spa/account/restaurantRegisterCtrl.js",
                 "~/Scripts/spa/recipies/recipiesCtrl.js",
                 "~/Scripts/spa/recipies/recipeAddCtrl.js",
                  //Added by Kranthi  ------------------------------------ start 
                  "~/Scripts/spa/Dashboard/usermanagementCtrl.js",
                //-----------------------------------------------------end
                // "~/Scripts/spa/inventoryitems/inventoryItem.directive.js",
                "~/Scripts/spa/inventoryitems/inventoryItemAddCtrl.js",
                "~/Scripts/spa/inventoryitems/inventoryitemsCtrl.js",
                "~/Scripts/spa/inventoryitems/inventoryItemEditCtrl.js",
                //Categories
                "~/Scripts/spa/settings/categoriesCtrl.js",
                "~/Scripts/spa/settings/categoryItemAddCtrl.js",
                "~/Scripts/spa/settings/categoryItemEditCtrl.js",
                //Units
                "~/Scripts/spa/settings/unitItemAddCtrl.js",
                "~/Scripts/spa/settings/unitDetailsCtrl.js",
                 "~/Scripts/spa/inventorysheet/inventoryAddCtrl.js",
                "~/Scripts/spa/inventorysheet/inventoryEditCtrl.js",
                 "~/Scripts/spa/inventorysheet/InventoryInvoiceCtrl.js",
                 "~/Scripts/spa/inventorysheet/inventoryDetailsCtrl.js",

                 //Added by Kranthi   -------------------------------------start
                 "~/Scripts/spa/admin/UserManagement/usersCtrl.js",
                 //-----------------------------------------------------end


                 //Vendor
                 "~/Scripts/spa/vendor/vendorAddCtrl.js",
                 "~/Scripts/spa/vendor/vendorEditCtrl.js",
                  "~/Scripts/spa/vendor/vendorsCtrl.js",
                  //Units
                  "~/Scripts/spa/admin/UserManagement/usersCtrl.js"




                ));





        }
        public static void RegisterStyles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/Content/StyleCss").Include(


               /******************************************/
               //BootStrap             
               "~/content/css/bootstrap.min.css",
               "~/content/css/managepad/AdminLTE.min.css",
               "~/content/css/managepad/skins.css",             
               "~/content/css/managepad/theme.css",
               "~/content/css/mplandingpage.css",
               "~/content/css/managepad/landingpage.css",

                "~/content/css/managepad/datepicker.min.css",
                 
                "~/content/css/managepad/datepicker3.min.css",

                /******************************************/








                // "~/content/css/Style/AdminLTE.min.css",
                //"~/content/css/Style/AdminLTE.css",


                //  "~/content/css/Style/all-skins.css",



                // "~/content/css/BSB/style.css",
                //  "~/content/css/landingpage.css",

                //  "~/content/css/mdb.min.css",




                //"~/content/css/Style/bootstraptheme.css",
                //   "~/content/css/bootstrap-theme.css",

                "~/content/css/dataTables.bootstrap.min.css",


                 // "~/content/css/bootstrap-datepicker.css",
                 // "~/content/css/datepicker3.css",
                 "~/content/css/morris.css",
                 "~/content/css/toastr.css",
                 "~/content/css/jquery.fancybox.css",
                 "~/content/css/loading-bar.css",


                  //"~/content/css/datepicker.css",
                  //replaced by jqueryUI
                  //"~/content/css/themes/base/all.css",

                  "~/content/css/animate.css",


                  "~/content/css/ms-form-wizard.css",
                "~/content/css/pricingtable.css",
                 "~/content/css/angular-material.css",
                "~/content/css/md-data-table-style.css",
                "~/content/css/md-data-table.css",
               "~/content/css/angular-toggle-switch.css",
               "~/content/css/angular-toggle-switch-bootstrap.css",
               "~/content/css/angular-ui-switch.css",
               "~/content/css/ngviewstyle.css",
                "~/content/css/ngPrint.css",
                "~/content/css/md-steppers.css",

                 "~/content/css/waves.min.css"




               //BootStrap             
               //"~/content/css/bootstrap.min.css",

               //----- BSB  -- STYLE ---//
               //Waves Effect Css -->
               //  "~/content/css/MPMaterial/node-waves/waves.min.css",

               //----- ADMIN LTE   -- STYLE ---//
               //  "~/content/css/AdminLTE/AdminLTE.min.css",
               //   "~/content/css/AdminLTE/bootstrap-material-design.min.css",

               //  "~/content/css/AdminLTE/ripples.min.css",
               //"~/content/css/AdminLTE/MaterialAdminLTE.css",
               // "~/content/css/AdminLTE/landingpage.css",
               //  "~/content/css/AdminLTE/all-md-skins.min.css",
               //   "~/content/css/AdminLTE/datepicker3.css",


               //"~/content/css/morris.css",
               //"~/content/css/toastr.css",
               //"~/content/css/jquery.fancybox.css",
               //"~/content/css/loading-bar.css",
               //"~/content/css/datepicker.css",
               //"~/content/css/ms-form-wizard.css",

               // "~/content/css/pricingtable.css",

               //Angular Material
               //"~/content/css/angular-material.css",
               //"~/content/css/md-data-table-style.css",
               //"~/content/css/md-data-table.css",

               //"~/content/css/angular-toggle-switch.css",
               //"~/content/css/angular-toggle-switch-bootstrap.css",
               //"~/content/css/angular-ui-switch.css",
               //"~/content/css/ngviewstyle.css",
               // "~/content/css/ngPrint.css",

               //Added on 09/08/2016  for MD stepper wizard
               //"~/content/css/md-steppers.css"

               ).Include("~/content/css/font-awesome.min.css", new CssRewriteUrlTransform()
               ).Include("~/content/css/ionicons.css", new CssRewriteUrlTransform())


               );


        }

    }
}