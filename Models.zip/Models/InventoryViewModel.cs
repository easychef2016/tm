﻿using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

using System.Web.Mvc;
using EasyChefDemo.Web.Infrastructure.Validators;

namespace EasyChefDemo.Web.Models
{
    public class InventoryViewModel : IValidatableObject
    {
        public int ID { get; set; }

        public string Name { get; set; }
        public Nullable<DateTime> InventoryDate { get; set; }

        public bool Status { get; set; }

        public string loginUserInfo { get; set; }

        public string Restaurant { get; set; }
        public int RestaurantId { get; set; }

        public string Vendor { get; set; }
        public int VendorId { get; set; }

        public int SenttoVendor { get; set; }
       public Nullable<DateTime> SenttoVendorDate { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new InventoryViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }
    }
}