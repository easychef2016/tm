﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using EasyChefDemo.Web.Infrastructure.Validators;

namespace EasyChefDemo.Web.Models
{
    public class ApprovedInventoryViewModel: IValidatableObject
    {
        public ApprovedInventoryViewModel()
        {
         
          
        }
                

        public int ID { get; set; }
        public Guid UniqueKey { get; set; }
        public int InventoryItemId { get; set; }

        public int InventoryId { get; set; }



        public decimal? Quantity { get; set; }
        public decimal? Price { get; set; }

        public decimal? ParValue { get; set; }
        public decimal? MinOrder { get; set; }
        public decimal? Order { get; set; }



        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }


        public int VendorId { get; set; }
        public string Vendor { get; set; }
        public int CategoryId { get; set; }
        public string Category { get; set; }



        public string InventoryItemName { get; set; }
        public string InventoryItemDescription { get; set; }

        public string InventoryItemUnit { get; set; }

        public virtual InventoryItemViewModel InventoryItems { get; set; }
        public virtual VendorViewModel Vendordetails { get; set; }
     
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new ApprovedInventoryViewModelValidators();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }
    }
}