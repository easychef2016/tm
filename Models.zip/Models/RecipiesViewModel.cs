﻿using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EasyChefDemo.Web.Models
{
    [Bind(Exclude = "Image")]
    public class RecipiesViewModel : IValidatableObject
    {

        public RecipiesViewModel()
        {
            RecipeIngredients = new HashSet<RecipeIngredientViewModel>();
            // InventoryItems = new List<InventoryItemViewModel>();
        }

        public int ID { get; set; }

        public string Name { get; set; }
        public decimal? SellingPrice { get; set; }
        public decimal? DesiredMargin { get; set; }
        public decimal? Ratio { get; set; }

        public string Description { get; set; }

        public decimal? PlateCost { get; set; }
        public decimal? DesiredPlateCost { get; set; }

        public decimal? Difference { get; set; }
        public decimal? ActualMargin { get; set; }
        public decimal? Margin { get; set; }
        public string Restaurant { get; set; }
        public int RestaurantId { get; set; }
        public string Image { get; set; }
        public int NumberOfRecipeIngrdients { get; set; }
       
        public ICollection<RecipeIngredientViewModel> RecipeIngredients { get; set; }
        //public ICollection<InventoryItemViewModel> InventoryItems { get; set; }
        public IList<InventoryItemViewModel> InventoryItems { get; set; }
       
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new RecipiesViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }


       

    }
}