﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using EasyChefDemo.Web.Infrastructure.Validators;

namespace EasyChefDemo.Web.Models
{
    public class InventoryInvoiceViewModel : IValidatableObject
    {
        public int ID { get; set; }
        public decimal? ApprovedQuantity { get; set; }
        public decimal? ApprovedPrice { get; set; }

        public decimal? ApprovedParValue { get; set; }
        public decimal? ApprovedMinOrder { get; set; }
        public decimal? ApprovedOrder { get; set; }

        public string InventoryItemName { get; set; }
        public string InventoryItemDescription { get; set; }

         public string InventoryItemUnit { get; set; }

        //Commented on 09/21/2016: to display vendor information with multiple contacts
         //public string Vendor { get; set; }

         public virtual VendorViewModel Vendor { get; set; }

         public virtual InventoryItemViewModel InventoryItems { get; set; }
         public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
         {
             var validator = new InventoryInvoiceViewModelValidators ();
             var result = validator.Validate(this);
             return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
         }

    }
}