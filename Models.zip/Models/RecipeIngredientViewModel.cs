﻿using EasyChefDemo.Web.Infrastructure.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EasyChefDemo.Web.Models
{
    public class RecipeIngredientViewModel : IValidatableObject
    {
        public RecipeIngredientViewModel()
        {
         
          //  InventoryItems = new List<InventoryItemViewModel>();
        }

        

        public int ID { get; set; }
        public Guid UniqueKey { get; set; }
        public int InventoryItemId { get; set; }
       

        
        public int RecipeId { get; set; }

    

        public decimal? Quantity { get; set; }
        public decimal? Price { get; set; }

        public decimal? TotalValue { get; set; }



        public bool Status { get; set; }

     //   public ICollection<InventoryItemViewModel> InventoryItems { get; set; }
        //SelectList InventoryItems;

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new RecipeIngredientViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }

    }
}